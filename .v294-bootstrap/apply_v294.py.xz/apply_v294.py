from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def write(path: str, content: str) -> None:
    (ROOT / path).write_text(content, encoding="utf-8")


def replace_once(path: str, old: str, new: str) -> None:
    source = read(path)
    count = source.count(old)
    if count != 1:
        raise SystemExit(f"{path}: expected one anchor, found {count}: {old[:120]!r}")
    write(path, source.replace(old, new))


# ---------------------------------------------------------------------------
# Version alignment
# ---------------------------------------------------------------------------
version_files = [
    "hub/app.py",
    "agent/agent.py",
    "darknoc",
    "install-hub.sh",
    "install-node.sh",
    "hub/static/index.html",
    "README.md",
    "README.fa.md",
    "NODE-README.md",
    "tests/smoke.py",
    "tests/realm_integration.py",
    "tests/local_hub_recovery.py",
    "tests/agent_heartbeat_resilience.py",
    "tests/topology_inventory_regression.py",
    "tests/installer_contracts.py",
]
for relative in version_files:
    source = read(relative)
    if "2.9.3" not in source:
        raise SystemExit(f"{relative}: v2.9.3 version anchor missing")
    write(relative, source.replace("2.9.3", "2.9.4"))

# ---------------------------------------------------------------------------
# Hub: lightweight pulse endpoint independent from full inventory validation
# ---------------------------------------------------------------------------
replace_once(
    "hub/app.py",
    '''class AgentReport(BaseModel):
''',
    '''class AgentPulse(BaseModel):
    agent_version: str = Field(default="unknown", min_length=1, max_length=64)
    agent_loop_ts: int | None = Field(default=None, ge=0)
    telemetry_status: str = Field(default="unknown", max_length=32)
    telemetry_age_seconds: int | None = Field(default=None, ge=0)
    inventory_error: str | None = Field(default=None, max_length=1000)


class AgentReport(BaseModel):
''',
)

pulse_endpoint = r'''

@app.post("/api/agent/pulse")
async def agent_pulse(report: AgentPulse, request: Request, node: sqlite3.Row = Depends(agent_node)):
    # Refresh liveness without parsing or mutating heavy inventory. A malformed,
    # oversized or temporarily stale report can never make a live Node offline.
    now = utc_ts()
    observed_ip = request.client.host if request.client else None
    if observed_ip in {"127.0.0.1", "::1"} and node["role"] == "hub":
        observed_ip = node["host"]
    with db() as conn:
        conn.execute(
            "UPDATE nodes SET status='online',agent_version=?,observed_ip=?,last_seen=?,updated_at=? WHERE id=?",
            (report.agent_version, observed_ip, now, now, node["id"]),
        )
        recovered = conn.execute(
            "SELECT id FROM incidents WHERE node_id=? AND tunnel_id IS NULL AND title LIKE 'Node % is offline' AND status IN ('open','acknowledged')",
            (node["id"],),
        ).fetchall()
        for incident in recovered:
            resolve_incident(conn, incident["id"], "Agent liveness pulse recovered")
    stale_clients: list[WebSocket] = []
    for live_socket in list(LIVE_CLIENTS):
        try:
            await live_socket.send_json(
                {"type": "telemetry", "node_id": node["id"], "server_time": now, "pulse": True}
            )
        except Exception:
            stale_clients.append(live_socket)
    for live_socket in stale_clients:
        LIVE_CLIENTS.discard(live_socket)
    return {"ok": True, "server_time": now}


'''
replace_once(
    "hub/app.py",
    "\ndef agent_inventory_flags(metrics: dict[str, Any]) -> tuple[bool, bool]:\n",
    pulse_endpoint + "def agent_inventory_flags(metrics: dict[str, Any]) -> tuple[bool, bool]:\n",
)

# ---------------------------------------------------------------------------
# Agent: pulse first, keep liveness up when full report is rejected, quarantine
# an incompatible cached payload instead of retrying it forever.
# ---------------------------------------------------------------------------
replace_once(
    "agent/agent.py",
    '''    consecutive_failures = 0

    async with httpx.AsyncClient(headers=headers, verify=verify_tls, timeout=timeout) as client:
''',
    '''    consecutive_failures = 0
    pulse_supported = True

    async with httpx.AsyncClient(headers=headers, verify=verify_tls, timeout=timeout) as client:
''',
)

agent_source = read("agent/agent.py")
start_marker = '''            heartbeat_ok = False
            try:
                response = await client.post(f"{hub}/api/agent/heartbeat", json=heartbeat_payload, timeout=10)
'''
end_marker = '''            try:
                if job_task is None or job_task.done():
'''
start = agent_source.find(start_marker)
end = agent_source.find(end_marker, start)
if start < 0 or end < 0:
    raise SystemExit("agent.py: heartbeat loop anchors missing")
new_heartbeat_block = r'''            pulse_ok = False
            heartbeat_ok = False
            pulse_error: str | None = None
            inventory_error: str | None = None
            pulse_payload = {
                "agent_version": VERSION,
                "agent_loop_ts": int(metrics.get("agent_loop_ts") or time.time()),
                "telemetry_status": str(metrics.get("telemetry_status") or "unknown")[:32],
                "telemetry_age_seconds": max(0, int(metrics.get("telemetry_age_seconds") or 0)),
                "inventory_error": str(state.get("last_inventory_error") or "")[:1000] or None,
            }

            if pulse_supported:
                try:
                    pulse_response = await client.post(
                        f"{hub}/api/agent/pulse", json=pulse_payload, timeout=6
                    )
                    if pulse_response.status_code == 404:
                        # Rolling upgrades may briefly run a new Agent against an
                        # older Hub. Fall back to the compatible heartbeat route.
                        pulse_supported = False
                    else:
                        if (
                            pulse_response.status_code == 401
                            and time.monotonic() - last_recovery_attempt >= 30
                        ):
                            last_recovery_attempt = time.monotonic()
                            if await recover_local_enrollment(client, hub, config):
                                pulse_response = await client.post(
                                    f"{hub}/api/agent/pulse", json=pulse_payload, timeout=6
                                )
                        pulse_response.raise_for_status()
                        pulse_ok = True
                        state["last_pulse_success"] = time.time()
                        state["last_pulse_status"] = pulse_response.status_code
                        state.pop("last_pulse_error", None)
                except Exception as exc:
                    pulse_error = f"{type(exc).__name__}: {exc}"[:1000]
                    state["last_pulse_error"] = pulse_error

            try:
                response = await client.post(
                    f"{hub}/api/agent/heartbeat", json=heartbeat_payload, timeout=10
                )
                if (
                    response.status_code == 401
                    and time.monotonic() - last_recovery_attempt >= 30
                ):
                    last_recovery_attempt = time.monotonic()
                    if await recover_local_enrollment(client, hub, config):
                        response = await client.post(
                            f"{hub}/api/agent/heartbeat", json=heartbeat_payload, timeout=10
                        )
                response.raise_for_status()
                heartbeat_ok = True
                state["last_inventory_success"] = time.time()
                state["last_heartbeat_status"] = response.status_code
                state.pop("last_inventory_error", None)
            except httpx.HTTPStatusError as exc:
                body = exc.response.text[-700:] if exc.response is not None else ""
                status_code = exc.response.status_code if exc.response is not None else 0
                inventory_error = (f"HTTP {status_code}: {body or str(exc)}")[:1000]
                state["last_inventory_error"] = inventory_error
                if pulse_ok and status_code in {400, 413, 422}:
                    # A cached report from an older schema must not poison every
                    # future heartbeat. Keep the pulse alive and rebuild inventory.
                    state.pop("last_payload", None)
                    state["last_payload_quarantined_at"] = time.time()
                    latest_payload = minimal_heartbeat_payload(config)
                    latest_telemetry_at = 0.0
                    LOGGER.warning(
                        "Inventory report rejected by Hub; cached snapshot quarantined while pulse remains online: %s",
                        inventory_error,
                    )
            except Exception as exc:
                inventory_error = f"{type(exc).__name__}: {exc}"[:1000]
                state["last_inventory_error"] = inventory_error

            liveness_ok = pulse_ok or heartbeat_ok
            if liveness_ok:
                consecutive_failures = 0
                state["last_success"] = time.time()
                state.pop("last_error", None)
            else:
                consecutive_failures += 1
                message = pulse_error or inventory_error or "Agent liveness request failed"
                state["last_error"] = message
                state["consecutive_heartbeat_failures"] = consecutive_failures
                if consecutive_failures == 1 or consecutive_failures % 4 == 0:
                    LOGGER.warning(
                        "Agent liveness failed (%s consecutive): %s",
                        consecutive_failures,
                        message,
                    )

'''
agent_source = agent_source[:start] + new_heartbeat_block + agent_source[end:]
status_old = '''            status = "Heartbeat OK" if heartbeat_ok else f"Heartbeat failures: {consecutive_failures}"
            systemd_notify(f"WATCHDOG=1\\nSTATUS={status}")
'''
status_new = '''            status = (
                "Pulse OK" if pulse_ok
                else "Heartbeat OK" if heartbeat_ok
                else f"Liveness failures: {consecutive_failures}"
            )
            if liveness_ok and inventory_error:
                status += " · inventory retrying"
            systemd_notify(f"WATCHDOG=1\\nSTATUS={status}")
'''
if agent_source.count(status_old) != 1:
    raise SystemExit("agent.py: watchdog status anchor mismatch")
agent_source = agent_source.replace(status_old, status_new)
write("agent/agent.py", agent_source)

# ---------------------------------------------------------------------------
# Discovery: valid DARK config directories are the source of truth. A stopped
# template instance or temporary systemd show failure must still be reported.
# ---------------------------------------------------------------------------
replace_once(
    "agent/agent.py",
    '''    else:
        complete = False

    filesystem_specs = (
''',
    '''    else:
        # Managed filesystem roots remain authoritative even if systemd's unit
        # listing is temporarily unavailable.
        LOGGER.warning("systemd unit listing failed during tunnel discovery: %s", output[-500:])

    filesystem_specs = (
''',
)

old_show = '''        show_code, properties = run(
            ["systemctl", "show", service, "--property=ExecStart", "--property=MainPID"],
            timeout=8,
        )
        if show_code != 0:
            complete = False
            cached = previous_by_service.get(service)
            if cached:
                discovered.append(cached)
            continue
        systemd_values: dict[str, str] = {}
        for line in properties.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                systemd_values[key] = value
        if str(expected_config) not in systemd_values.get("ExecStart", ""):
            # A matching unit name without the DARK config path is not ours.
            continue
'''
new_show = '''        filesystem_owned = expected_config.is_file()
        show_code, properties = run(
            ["systemctl", "show", service, "--property=ExecStart", "--property=MainPID"],
            timeout=8,
        )
        systemd_values: dict[str, str] = {}
        if show_code == 0:
            for line in properties.splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    systemd_values[key] = value
        elif not filesystem_owned:
            complete = False
            cached = previous_by_service.get(service)
            if cached:
                discovered.append(cached)
            continue
        if not filesystem_owned and str(expected_config) not in systemd_values.get("ExecStart", ""):
            # A matching loaded unit without an owned DARK config path is not ours.
            continue
'''
replace_once("agent/agent.py", old_show, new_show)

# ---------------------------------------------------------------------------
# Topology: restore a solid glowing backbone and animate bright data comets over
# it. Keep compact dynamic lanes and the v2.9.3 role/pairing corrections.
# ---------------------------------------------------------------------------
replace_once(
    "hub/static/app.js",
    '''  const defs=`<defs><filter id="cyber-glow"><feGaussianBlur stdDeviation="2.8" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter><marker id="route-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10Z" fill="currentColor"/></marker></defs>`;
''',
    '''  const defs=`<defs><filter id="cyber-glow"><feGaussianBlur stdDeviation="2.8" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="packet-glow"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter><marker id="route-arrow" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="currentColor"/></marker></defs>`;
''',
)

old_routes = '''    const duration=Math.max(1.4,7-Math.log10(link.rate+1));
    const packets=link.tone==='online'?`<circle class="route-packet" r="3"><animateMotion dur="${duration.toFixed(1)}s" repeatCount="indefinite"><mpath href="#route-${index}"/></animateMotion></circle><circle class="route-packet" r="2" opacity=".65"><animateMotion begin="-${(duration/2).toFixed(1)}s" dur="${duration.toFixed(1)}s" repeatCount="indefinite"><mpath href="#route-${index}"/></animateMotion></circle>`:'';
    return `<g class="route-group ${link.tone}" data-route="${index}" tabindex="0"><path class="route-hit" d="${path}"/><path id="route-${index}" class="cyber-route" style="--route-width:${width.toFixed(2)}" d="${path}"/>${packets}<text class="route-label" x="450" y="${((y1+y2)/2+offset-7).toFixed(1)}" text-anchor="middle">${esc(link.tunnel.name)} · ${esc(String(link.tunnel.transport||link.tunnel.method).toUpperCase())}</text></g>`;
'''
new_routes = '''    const duration=Math.max(1.25,6.2-Math.log10(link.rate+1));
    const packetCount=link.tone==='online'?(link.rate>10000000?4:link.rate>1000000?3:2):link.tone==='degraded'?1:0;
    const packets=Array.from({length:packetCount},(_,packetIndex)=>{
      const begin=-(duration/Math.max(packetCount,1))*packetIndex;
      return `<circle class="route-packet-halo" r="7"><animateMotion begin="${begin.toFixed(2)}s" dur="${duration.toFixed(2)}s" repeatCount="indefinite"><mpath href="#route-${index}"/></animateMotion></circle><circle class="route-packet-core" r="3.2"><animateMotion begin="${begin.toFixed(2)}s" dur="${duration.toFixed(2)}s" repeatCount="indefinite"><mpath href="#route-${index}"/></animateMotion></circle>`;
    }).join('');
    return `<g class="route-group ${link.tone}" data-route="${index}" tabindex="0"><path class="route-hit" d="${path}"/><path id="route-${index}" class="cyber-route-backbone" style="--route-width:${width.toFixed(2)}" d="${path}" marker-end="url(#route-arrow)"/><path class="cyber-route-flow" pathLength="100" style="--route-width:${width.toFixed(2)};--flow-duration:${duration.toFixed(2)}s" d="${path}"/>${packets}<text class="route-label" x="450" y="${((y1+y2)/2+offset-7).toFixed(1)}" text-anchor="middle">${esc(link.tunnel.name)} · ${esc(String(link.tunnel.transport||link.tunnel.method).toUpperCase())}</text></g>`;
'''
replace_once("hub/static/app.js", old_routes, new_routes)

old_css = '''.cyber-route{fill:none;stroke:currentColor;stroke-width:var(--route-width,1.8);stroke-dasharray:9 8;filter:url(#cyber-glow);animation:dash 12s linear infinite;pointer-events:none}.route-group.down .cyber-route{animation-duration:3s}.route-hit{fill:none;stroke:transparent;stroke-width:18;pointer-events:stroke}.route-group:hover .cyber-route,.route-group:focus .cyber-route{stroke-width:calc(var(--route-width,1.8) + 2);stroke-dasharray:3 4}.cyber-node'''
new_css = '''.cyber-route-backbone{fill:none;stroke:currentColor;stroke-width:var(--route-width,1.8);stroke-linecap:round;opacity:.58;filter:url(#cyber-glow);pointer-events:none;vector-effect:non-scaling-stroke;transition:opacity .18s,stroke-width .18s}.cyber-route-flow{fill:none;stroke:currentColor;stroke-width:calc(var(--route-width,1.8) + .9);stroke-linecap:round;stroke-dasharray:13 87;stroke-dashoffset:100;opacity:.96;filter:url(#cyber-glow);pointer-events:none;vector-effect:non-scaling-stroke;animation:route-data-flow var(--flow-duration,3s) linear infinite}.route-group.degraded .cyber-route-flow{opacity:.72;animation-duration:calc(var(--flow-duration,3s) * 1.35)}.route-group.down .cyber-route-flow{display:none}.route-group.down .cyber-route-backbone{opacity:.45;animation:route-danger-pulse 1.35s ease-in-out infinite}.route-hit{fill:none;stroke:transparent;stroke-width:20;pointer-events:stroke}.route-group:hover .cyber-route-backbone,.route-group:focus .cyber-route-backbone{stroke-width:calc(var(--route-width,1.8) + 2);opacity:1}.route-group:hover .cyber-route-flow,.route-group:focus .cyber-route-flow{stroke-width:calc(var(--route-width,1.8) + 2.8)}.route-packet-halo{fill:currentColor;opacity:.2;filter:url(#packet-glow);pointer-events:none}.route-packet-core{fill:#ecfff7;stroke:currentColor;stroke-width:1;filter:url(#packet-glow);pointer-events:none}.route-label{paint-order:stroke;stroke:#05090d;stroke-width:6px;stroke-linejoin:round;fill:#b7c8d2;font:700 10px ui-monospace,monospace;letter-spacing:.02em;pointer-events:none}@keyframes route-data-flow{to{stroke-dashoffset:0}}@keyframes route-danger-pulse{0%,100%{opacity:.25}50%{opacity:.8}}.cyber-node'''
replace_once("hub/static/styles.css", old_css, new_css)

replace_once(
    "hub/static/app.js",
    '''  const canvasHeight=Math.max(414,80+laneCount*104);
''',
    '''  const canvasHeight=Math.max(414,72+laneCount*92);
''',
)

# ---------------------------------------------------------------------------
# Regression coverage and release gates
# ---------------------------------------------------------------------------
test_path = "tests/topology_inventory_regression.py"
test_source = read(test_path)
pulse_test_anchor = '''        auth = {"Authorization": f"Bearer {token}"}

        full_report = {
'''
pulse_test_insert = '''        auth = {"Authorization": f"Bearer {token}"}

        pulse = client.post(
            "/api/agent/pulse",
            headers=auth,
            json={
                "agent_version": "2.9.4",
                "agent_loop_ts": app.utc_ts(),
                "telemetry_status": "collecting",
                "telemetry_age_seconds": 0,
            },
        )
        assert pulse.status_code == 200
        with app.db() as conn:
            pulsed = conn.execute("SELECT status,last_seen FROM nodes WHERE id=?", (hub_id,)).fetchone()
            assert pulsed["status"] == "online" and int(pulsed["last_seen"] or 0) > 0

        full_report = {
'''
if test_source.count(pulse_test_anchor) != 1:
    raise SystemExit("topology test pulse anchor mismatch")
test_source = test_source.replace(pulse_test_anchor, pulse_test_insert)
test_source = test_source.replace(
    '''assert "topology_side" in app_js and "pairTotals" in app_js
assert "--topology-canvas-height" in app_js and "--topology-canvas-height" in styles
assert "No matching tunnel path" in app_js
''',
    '''assert "topology_side" in app_js and "pairTotals" in app_js
assert "--topology-canvas-height" in app_js and "--topology-canvas-height" in styles
assert "cyber-route-backbone" in app_js and "cyber-route-flow" in app_js
assert ".cyber-route-backbone" in styles and "@keyframes route-data-flow" in styles
assert "route-packet-core" in app_js and "route-packet-halo" in app_js
assert "No matching tunnel path" in app_js
''',
)
write(test_path, test_source)

resilience = read("tests/agent_heartbeat_resilience.py")
resilience_anchor = '''assert "recover_local_enrollment" in source and "WATCHDOG=1" in source
'''
if resilience.count(resilience_anchor) != 1:
    raise SystemExit("agent resilience assertion anchor mismatch")
resilience = resilience.replace(
    resilience_anchor,
    resilience_anchor + 'assert "/api/agent/pulse" in source and "last_payload_quarantined_at" in source\n',
)
write("tests/agent_heartbeat_resilience.py", resilience)

release_path = ".github/workflows/release.yml"
release = read(release_path)
topology_gate = "          python tests/topology_inventory_regression.py\n"
if topology_gate not in release:
    release_anchor = "          python tests/agent_heartbeat_resilience.py\n"
    if release_anchor not in release:
        raise SystemExit("release workflow test anchor missing")
    release = release.replace(release_anchor, release_anchor + topology_gate)
write(release_path, release)

ci = read(".github/workflows/ci.yml")
if topology_gate not in ci:
    raise SystemExit("CI topology regression gate missing")

# ---------------------------------------------------------------------------
# Documentation
# ---------------------------------------------------------------------------
release_note = '''# DARK NOC v2.9.4 — Hub Pulse & Live Route Flow

This maintenance release makes Hub liveness independent from full inventory
validation. Every Agent sends a small authenticated pulse first; malformed,
oversized or schema-incompatible telemetry can no longer mark a running Hub
offline. Rejected cached reports are quarantined and rebuilt automatically.

Tunnel discovery now trusts valid DARK configuration directories even when a
stopped template instance cannot be queried through systemd. The cyber topology
keeps the corrected role/pairing model from v2.9.3 while restoring a solid
glowing route, animated throughput flow and moving data comets.

---

'''
write("RELEASE_NOTES.md", release_note + read("RELEASE_NOTES.md"))

changelog_note = '''## 2.9.4

- Added an authenticated lightweight Agent pulse endpoint so Hub and Node
  liveness no longer depends on full telemetry acceptance.
- Quarantine incompatible cached inventory and rebuild it while liveness stays
  online.
- Discover filesystem-owned DARK tunnels even when their stopped systemd
  instance cannot be inspected.
- Restored solid glowing topology routes with animated data flow and moving
  packet comets.
- Added permanent pulse, inventory and topology visual regression coverage.

'''
write("CHANGELOG.md", changelog_note + read("CHANGELOG.md"))

print("DARK NOC v2.9.4 patch applied")
