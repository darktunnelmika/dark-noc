#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Any

import httpx
import psutil

VERSION = "1.6.2"
CONFIG_PATH = Path(os.getenv("DARK_NOC_AGENT_CONFIG", "/etc/dark-noc-agent/config.json"))
STATE_PATH = Path(os.getenv("DARK_NOC_AGENT_STATE", "/var/lib/dark-noc-agent/state.json"))
ALLOWED_JOB_KINDS = {"diagnostics", "tunnel_test", "restart_service", "service_status", "speed_test", "logs", "plugin_deploy", "plugin_remove", "configure_autoheal"}

DARKBH_RELEASE_API = "https://api.github.com/repos/Musixal/Backhaul/releases/latest"
_CONNECTION_SNAPSHOT: list[Any] = []


def refresh_connection_snapshot() -> list[Any]:
    global _CONNECTION_SNAPSHOT
    try:
        _CONNECTION_SNAPSHOT = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, OSError):
        _CONNECTION_SNAPSHOT = []
    return _CONNECTION_SNAPSHOT


def connections_snapshot() -> list[Any]:
    return _CONNECTION_SNAPSHOT


def load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, indent=2))
    os.chmod(tmp, 0o600)
    tmp.replace(path)


def run(command: list[str], timeout: int = 20) -> tuple[int, str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
        output = (result.stdout + result.stderr)[-200_000:]
        return result.returncode, output
    except subprocess.TimeoutExpired:
        return 124, "Command timed out"
    except Exception as exc:
        return 1, str(exc)


def systemd_status(service: str) -> str:
    code, _ = run(["systemctl", "is-active", service], timeout=8)
    return "active" if code == 0 else "inactive"


async def tcp_probe(host: str, port: int, timeout: float = 4.0) -> tuple[bool, float | None]:
    started = time.perf_counter()
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout)
        writer.close()
        await writer.wait_closed()
        return True, round((time.perf_counter() - started) * 1000, 2)
    except Exception:
        return False, None


async def tcp_sample(host: str, port: int, attempts: int = 3) -> tuple[str, float | None, float]:
    samples = [await tcp_probe(host, port) for _ in range(attempts)]
    latencies = [latency for ok, latency in samples if ok and latency is not None]
    loss = round((attempts - len(latencies)) * 100 / attempts, 1)
    status = "healthy" if loss == 0 else "degraded" if latencies else "down"
    return status, round(sum(latencies) / len(latencies), 2) if latencies else None, loss


def port_sessions(port: int) -> int:
    if not port:
        return 0
    try:
        return sum(
            1 for conn in connections_snapshot()
            if conn.status == psutil.CONN_ESTABLISHED and (
                (conn.laddr and conn.laddr.port == port) or
                (conn.raddr and conn.raddr.port == port)
            )
        )
    except (psutil.AccessDenied, OSError):
        return 0


def socket_state(port: int, remote_host: str | None = None) -> tuple[bool, int]:
    try:
        connections = connections_snapshot()
        if remote_host is None:
            listening = any(conn.status == psutil.CONN_LISTEN and conn.laddr and conn.laddr.port == port for conn in connections)
            sessions = sum(1 for conn in connections if conn.status == psutil.CONN_ESTABLISHED and conn.laddr and conn.laddr.port == port)
            return listening, sessions
        targets = {remote_host}
        try:
            targets.add(socket.gethostbyname(remote_host))
        except OSError:
            pass
        sessions = sum(1 for conn in connections if conn.status == psutil.CONN_ESTABLISHED and conn.raddr and conn.raddr.port == port and conn.raddr.ip in targets)
        return sessions > 0, sessions
    except (psutil.AccessDenied, OSError):
        return False, 0


def _port_is_listening(port: int) -> bool:
    try:
        connections = connections_snapshot() or refresh_connection_snapshot()
        return any(conn.status == psutil.CONN_LISTEN and conn.laddr and conn.laddr.port == port for conn in connections)
    except (psutil.AccessDenied, OSError):
        code, output = run(["ss", "-H", "-lntup"], timeout=10)
        return code == 0 and re.search(fr":{port}\b", output) is not None


def _darkbh_preflight(name: str, role: str, endpoint: str, tunnel_port: int, user_ports: list[int]) -> None:
    required = ["systemctl", "tar"]
    missing = [command for command in required if shutil.which(command) is None]
    if missing:
        raise RuntimeError(f"Missing required commands: {', '.join(missing)}")
    if shutil.disk_usage("/usr/local").free < 64 * 1024 * 1024:
        raise RuntimeError("Less than 64 MiB free space is available")
    service = f"backhaul@{name}.service"
    if systemd_status(service) == "active" or (Path("/etc/dark-backhaul/tunnels") / name).exists():
        raise RuntimeError(f"Tunnel {name} already exists on this node")
    if role == "server":
        conflicts = [port for port in [tunnel_port, *user_ports] if _port_is_listening(port)]
        if conflicts:
            raise RuntimeError(f"Port conflict detected: {', '.join(map(str, conflicts))}")
    else:
        try:
            socket.getaddrinfo(endpoint, tunnel_port, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise RuntimeError(f"Endpoint DNS/IP resolution failed: {exc}") from exc
        missing = [port for port in user_ports if not _port_is_listening(port)]
        if missing:
            raise RuntimeError(f"Kharej destination port(s) are not listening locally: {', '.join(map(str, missing))}")


def connection_count() -> int:
    try:
        return len(connections_snapshot())
    except Exception:
        return 0


def base_metrics(previous: dict[str, Any]) -> dict[str, Any]:
    net = psutil.net_io_counters()
    now = time.time()
    prior_ts = float(previous.get("ts", now))
    seconds = max(now - prior_ts, 1)
    rx_bps = max(0, (net.bytes_recv - int(previous.get("bytes_recv", net.bytes_recv))) * 8 / seconds)
    tx_bps = max(0, (net.bytes_sent - int(previous.get("bytes_sent", net.bytes_sent))) * 8 / seconds)
    disk = psutil.disk_usage("/")
    boot = psutil.boot_time()
    return {
        "hostname": socket.gethostname(),
        "cpu": psutil.cpu_percent(interval=0.4),
        "ram": psutil.virtual_memory().percent,
        "swap": psutil.swap_memory().percent,
        "disk": disk.percent,
        "load1": os.getloadavg()[0],
        "rx_bps": round(rx_bps, 2),
        "tx_bps": round(tx_bps, 2),
        "uptime": int(now - boot),
        "connections": connection_count(),
        "bytes_recv": net.bytes_recv,
        "bytes_sent": net.bytes_sent,
        "ts": now,
    }


async def tunnel_report(tunnel: dict[str, Any]) -> dict[str, Any]:
    service = str(tunnel.get("service", ""))
    target_host = str(tunnel.get("target_host", "127.0.0.1"))
    target_port = int(tunnel.get("target_port", 0))
    service_ok = not service or systemd_status(service) == "active"
    method = str(tunnel.get("method", "custom"))
    role = str(tunnel.get("role", ""))
    if method == "DARK Backhaul" and not role:
        role = "server" if tunnel.get("listen_port") else "client"
    if method == "DARK Backhaul" and role == "server":
        listening, sessions = socket_state(target_port)
        connected = listening and sessions > 0
        user_ports = [int(port) for port in tunnel.get("user_ports", []) if str(port).isdigit()]
        if user_ports:
            sessions = sum(port_sessions(port) for port in user_ports)
        path_status, latency, packet_loss = ("healthy" if connected else "down"), None, (0 if connected else 100)
    elif method == "DARK Backhaul" and role == "client":
        connected, sessions = socket_state(target_port, target_host)
        path_status, latency, packet_loss = ("healthy" if connected else "degraded"), None, (0 if connected else 100)
    elif target_port:
        path_status, latency, packet_loss = await tcp_sample(target_host, target_port)
        sessions = port_sessions(int(tunnel.get("listen_port") or target_port or 0))
    else:
        path_status, latency, packet_loss = ("healthy" if service_ok else "down"), None, (0 if service_ok else 100)
        sessions = 0
    status = path_status if service_ok else "down"
    return {
        "name": str(tunnel.get("name", service or f"tcp-{target_port}")),
        "method": method,
        "target": f"{target_host}:{target_port}" if target_port else "local",
        "service": service,
        "listen_port": tunnel.get("listen_port"),
        "status": status,
        "latency_ms": latency,
        "packet_loss": packet_loss,
        "sessions": sessions,
        "rx_bps": None,
        "tx_bps": None,
        "checks": {"process": service_ok, "path": path_status != "down"},
    }


async def _collect_tunnel_reports(tunnels: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return list(await asyncio.gather(*(tunnel_report(item) for item in tunnels)))


DARK_BACKHAUL_SERVICE_PATTERN = re.compile(r"^backhaul@[A-Za-z0-9_-]{1,64}\.service$")
_DISCOVERY_CACHE: tuple[float, list[dict[str, Any]]] = (0.0, [])


def discover_tunnels() -> list[dict[str, Any]]:
    """Discover only DARK Backhaul plugin instances; ignore every other tunnel family."""
    global _DISCOVERY_CACHE
    if time.time() - _DISCOVERY_CACHE[0] < 60:
        return [dict(item) for item in _DISCOVERY_CACHE[1]]
    code, output = run(["systemctl", "list-units", "--type=service", "--all", "--no-legend", "--plain"], timeout=15)
    if code != 0:
        return []
    services: list[str] = []
    for line in output.splitlines():
        parts = line.split()
        if not parts:
            continue
        service = parts[0]
        if DARK_BACKHAUL_SERVICE_PATTERN.fullmatch(service):
            services.append(service)
    try:
        connections = connections_snapshot()
    except (psutil.AccessDenied, OSError):
        connections = []
    discovered: list[dict[str, Any]] = []
    for service in sorted(set(services))[:128]:
        instance = service.removeprefix("backhaul@").removesuffix(".service")
        tunnel_dir = Path("/etc/dark-backhaul/tunnels") / instance
        expected_config = tunnel_dir / "config.toml"
        _, exec_start = run(["systemctl", "show", service, "--property=ExecStart", "--value"], timeout=8)
        if str(expected_config) not in exec_start:
            continue
        meta: dict[str, str] = {}
        try:
            for raw_line in (tunnel_dir / "meta.conf").read_text().splitlines():
                if "=" in raw_line:
                    key, value = raw_line.split("=", 1)
                    meta[key.strip()] = value.strip().strip('"')
        except OSError:
            pass
        _, pid_text = run(["systemctl", "show", service, "--property=MainPID", "--value"], timeout=8)
        try:
            root_pid = int(pid_text.strip())
        except ValueError:
            root_pid = 0
        pids = {root_pid} if root_pid > 0 else set()
        if root_pid > 0:
            try:
                pids.update(child.pid for child in psutil.Process(root_pid).children(recursive=True))
            except (psutil.Error, OSError):
                pass
        owned = [conn for conn in connections if conn.pid in pids]
        listeners = sorted({conn.laddr.port for conn in owned if conn.status == psutil.CONN_LISTEN and conn.laddr})
        remotes = [conn.raddr for conn in owned if conn.status == psutil.CONN_ESTABLISHED and conn.raddr]
        method = "DARK Backhaul"
        configured_role = meta.get("ROLE", "")
        configured_port = int(meta.get("PORT", "0")) if meta.get("PORT", "").isdigit() else 0
        listen_port = configured_port if configured_role == "server" else None
        remote = remotes[0] if remotes else None
        role = configured_role if configured_role in {"server", "client"} else ("server" if listeners else "client")
        target_host = "127.0.0.1" if role == "server" else (meta.get("PEER_IP") or (remote.ip if remote else "127.0.0.1"))
        target_port = configured_port or (remote.port if remote else 0)
        user_ports: list[int] = []
        try:
            user_ports = [int(line.split()[0]) for line in (tunnel_dir / "ports.list").read_text().splitlines() if line.split() and line.split()[0].isdigit()]
        except OSError:
            pass
        discovered.append({
            "name": instance, "method": method, "role": role,
            "service": service, "listen_port": listen_port, "target_host": target_host,
            "target_port": target_port, "user_ports": user_ports, "auto_discovered": True,
        })
    _DISCOVERY_CACHE = (time.time(), discovered)
    return [dict(item) for item in discovered]


def monitored_tunnels(config: dict[str, Any]) -> list[dict[str, Any]]:
    explicit = [
        item for item in config.get("tunnels", [])
        if str(item.get("method", "")) == "DARK Backhaul"
        and DARK_BACKHAUL_SERVICE_PATTERN.fullmatch(str(item.get("service", "")))
    ]
    if not config.get("auto_discovery", True):
        return explicit
    known_services = {str(item.get("service", "")) for item in explicit if item.get("service")}
    known_names = {str(item.get("name", "")) for item in explicit}
    automatic = [item for item in discover_tunnels() if item["service"] not in known_services and item["name"] not in known_names]
    return explicit + automatic


def service_reports(config: dict[str, Any]) -> list[dict[str, str]]:
    result = []
    discovered_services = [item["service"] for item in discover_tunnels()] if config.get("auto_discovery", True) else []
    for service in dict.fromkeys([*config.get("services", []), *discovered_services]):
        service = str(service)
        result.append({"name": service, "status": systemd_status(service)})
    return result


def restart_allowed(service: str, config: dict[str, Any]) -> bool:
    return service in {str(item) for item in config.get("managed_services", [])}


def _download(url: str, destination: Path, timeout: int = 240, max_bytes: int = 128 * 1024 * 1024) -> str:
    if not url.startswith("https://"):
        raise RuntimeError("Plugin downloads require HTTPS")
    digest = hashlib.sha256()
    received = 0
    with httpx.stream("GET", url, follow_redirects=True, timeout=timeout) as response:
        response.raise_for_status()
        with destination.open("wb") as handle:
            for chunk in response.iter_bytes():
                received += len(chunk)
                if received > max_bytes:
                    raise RuntimeError("Plugin download exceeded the 128 MiB safety limit")
                digest.update(chunk)
                handle.write(chunk)
    return digest.hexdigest()


def _install_darkbh_core() -> str:
    Path("/etc/dark-backhaul").mkdir(parents=True, exist_ok=True)

    arch = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64", "armv7l": "arm", "i386": "386", "i686": "386"}.get(os.uname().machine)
    if not arch:
        raise RuntimeError(f"Unsupported CPU architecture: {os.uname().machine}")
    core_path = Path("/usr/local/bin/backhaul")
    if core_path.exists() and os.access(core_path, os.X_OK):
        code, version = run([str(core_path), "-v"], timeout=10)
        if code == 0:
            return version.strip() or "installed (existing core preserved)"
    release = httpx.get(DARKBH_RELEASE_API, follow_redirects=True, timeout=40)
    release.raise_for_status()
    release_data = release.json()
    release_tag = str(release_data.get("tag_name", "")).lstrip("v")
    candidates = [asset for asset in release_data.get("assets", []) if re.search(fr"linux[_-]{arch}", asset.get("name", ""), re.I) and not re.search(r"\.(sha256|asc|sig|txt|md5)$", asset.get("name", ""), re.I)]
    if not candidates:
        raise RuntimeError(f"No official Backhaul linux_{arch} release asset found")
    asset = next((item for item in candidates if re.search(r"\.(tar\.gz|tgz)$", item["name"], re.I)), candidates[0])
    with tempfile.TemporaryDirectory(prefix="darkbh-") as tmp_name:
        tmp = Path(tmp_name)
        package = tmp / asset["name"]
        actual_digest = _download(asset["browser_download_url"], package)
        expected_digest = str(asset.get("digest") or "")
        if not expected_digest.startswith("sha256:") or not hmac.compare_digest(expected_digest.removeprefix("sha256:"), actual_digest):
            raise RuntimeError("Backhaul release asset has no valid matching SHA-256 digest")
        unpacked = tmp / "unpacked"
        unpacked.mkdir()
        if re.search(r"\.(tar\.gz|tgz)$", asset["name"], re.I):
            try:
                with tarfile.open(package, "r:gz") as archive:
                    members = archive.getmembers()
                    if any((not member.isfile() and not member.isdir()) or member.name.startswith("/") or ".." in Path(member.name).parts for member in members):
                        raise RuntimeError("Unsafe path, link or special file found in Backhaul release archive")
                    archive.extractall(unpacked, members=members)
            except (tarfile.TarError, OSError) as exc:
                raise RuntimeError(f"Backhaul core extraction failed: {exc}") from exc
            binaries = [p for p in unpacked.rglob("backhaul*") if p.is_file() and not p.name.endswith((".md", ".toml"))]
        else:
            binaries = [package]
        if not binaries:
            raise RuntimeError("Backhaul binary was not found in official release")
        candidate = binaries[0]
        os.chmod(candidate, 0o755)
        code, output = run([str(candidate), "-v"], timeout=10)
        if code != 0:
            raise RuntimeError(f"Backhaul binary verification failed: {output[-500:]}")
        core_tmp = Path("/usr/local/bin/.backhaul.new")
        shutil.copy2(candidate, core_tmp)
        os.chmod(core_tmp, 0o755)
        core_tmp.replace(core_path)
        Path("/etc/dark-backhaul/core.version").write_text(str(release_data.get("tag_name", "latest")) + "\n")
        return output.strip() or str(release_data.get("tag_name", "installed"))


def _profile_values(profile: str) -> dict[str, Any]:
    values = {
        "stable": (4, 1024, 30, 20, 4, "false", 3, 10),
        "balanced": (8, 2048, 40, 75, 8, "false", 3, 10),
        "lowping": (16, 2048, 20, 20, 8, "true", 1, 5),
        "turbo": (24, 4096, 40, 60, 16, "true", 2, 10),
    }[profile]
    return dict(zip(("pool", "channel", "heartbeat", "keepalive", "muxcon", "aggressive", "retry", "dial"), values))


def _configure_ufw(tunnel_dir: Path, name: str, role: str, transport: str, tunnel_port: int, user_ports: list[int]) -> list[str]:
    if role != "server" or shutil.which("ufw") is None:
        return []
    code, status = run(["ufw", "status"], timeout=15)
    if code != 0 or "Status: active" not in status:
        return []
    requested = [(tunnel_port, "udp" if transport == "udp" else "tcp"), *[(port, "tcp") for port in user_ports]]
    created: list[str] = []
    for port, protocol in requested:
        rule = f"{port}/{protocol}"
        code, output = run(["ufw", "allow", rule, "comment", f"DARK-NOC-{name}"], timeout=20)
        if code != 0:
            raise RuntimeError(f"Could not open UFW rule {rule}: {output[-500:]}")
        if "Rule added" in output:
            created.append(rule)
    (tunnel_dir / "ufw-created.json").write_text(json.dumps(created))
    return created


def _deploy_dark_backhaul(payload: dict[str, Any], config: dict[str, Any]) -> str:
    if payload.get("plugin_id") != "dark-backhaul":
        raise ValueError("Plugin is not allowlisted")
    name, role = str(payload.get("name", "")), str(payload.get("role", ""))
    endpoint, token = str(payload.get("endpoint", "")), str(payload.get("token", ""))
    transport, profile = str(payload.get("transport", "")), str(payload.get("profile", ""))
    tunnel_port, ports = int(payload.get("tunnel_port", 0)), [int(p) for p in payload.get("user_ports", [])]
    restart_every = str(payload.get("restart_every", "off"))
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,24}", name) or role not in {"server", "client"}:
        raise ValueError("Invalid tunnel identity or role")
    if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", endpoint) or not re.fullmatch(r"[A-Za-z0-9]{8,128}", token):
        raise ValueError("Invalid endpoint or pairing token")
    if transport not in {"tcp", "tcpmux", "ws", "wsmux", "udp"} or profile not in {"stable", "balanced", "lowping", "turbo"}:
        raise ValueError("Unsupported transport or profile")
    if not 1 <= tunnel_port <= 65535 or not ports or any(not 1 <= p <= 65535 or p == tunnel_port for p in ports):
        raise ValueError("Invalid tunnel/user ports")
    if restart_every not in {"off", "1h", "6h", "12h", "24h"}:
        raise ValueError("Invalid restart interval")

    tunnel_dir = Path("/etc/dark-backhaul/tunnels") / name
    existing_meta = load_json(tunnel_dir / "deployment.json", {})
    identity = {"role": role, "endpoint": endpoint, "tunnel_port": tunnel_port, "user_ports": sorted(set(ports)), "transport": transport, "profile": profile}
    if existing_meta == identity and systemd_status(f"backhaul@{name}.service") == "active":
        return f"DARK Backhaul tunnel {name} is already deployed and active"
    _darkbh_preflight(name, role, endpoint, tunnel_port, ports)
    core_version = _install_darkbh_core()
    base = Path("/etc/dark-backhaul")
    tunnel_dir = base / "tunnels" / name
    tunnel_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(base, 0o700)
    (tunnel_dir / "ports.list").write_text("".join(f"{port}\t-\n" for port in ports) if role == "server" else "")
    p = _profile_values(profile)
    common = [
        f'transport = "{transport}"', f'token = "{token}"', f'keepalive_period = {p["keepalive"]}',
        'nodelay = true', 'sniffer = false', 'web_port = 0', f'sniffer_log = "{tunnel_dir}/sniffer.json"', 'log_level = "info"',
    ]
    if role == "server":
        lines = ["[server]", f'bind_addr = "0.0.0.0:{tunnel_port}"', *common, f'heartbeat = {p["heartbeat"]}', f'channel_size = {p["channel"]}']
        if transport.endswith("mux"):
            lines += [f'mux_con = {p["muxcon"]}', 'mux_version = 1', 'mux_framesize = 32768', 'mux_recievebuffer = 4194304', 'mux_streambuffer = 65536']
        lines += ["ports = [", *[f'  "{port}",' for port in ports], "]"]
    else:
        lines = ["[client]", f'remote_addr = "{endpoint}:{tunnel_port}"', *common, f'connection_pool = {p["pool"]}', f'aggressive_pool = {p["aggressive"]}', f'dial_timeout = {p["dial"]}', f'retry_interval = {p["retry"]}']
        if transport.endswith("mux"):
            lines += ['mux_version = 1', 'mux_framesize = 32768', 'mux_recievebuffer = 4194304', 'mux_streambuffer = 65536']
    (tunnel_dir / "config.toml").write_text("\n".join(lines) + "\n")
    meta = {"NAME": name, "ROLE": role, "PORT": tunnel_port, "TOKEN": token, "TRANSPORT": transport, "PROFILE": profile, "PEER_IP": endpoint if role == "client" else "", "PUB_IP": endpoint if role == "server" else "", "RESTART_EVERY": restart_every}
    (tunnel_dir / "meta.conf").write_text("".join(f'{key}="{value}"\n' for key, value in meta.items()))
    for path in (tunnel_dir / "config.toml", tunnel_dir / "meta.conf"):
        os.chmod(path, 0o600)
    save_json(tunnel_dir / "deployment.json", identity)
    unit = """[Unit]\nDescription=DARK VPN Backhaul Tunnel (%i)\nAfter=network-online.target\nWants=network-online.target\nStartLimitIntervalSec=0\n\n[Service]\nType=simple\nExecStart=/usr/local/bin/backhaul -c /etc/dark-backhaul/tunnels/%i/config.toml\nRestart=always\nTimeoutStopSec=10\nKillMode=mixed\nRestartSec=5\nLimitNOFILE=1048576\nStandardOutput=journal\nStandardError=journal\n\n[Install]\nWantedBy=multi-user.target\n"""
    Path("/etc/systemd/system/backhaul@.service").write_text(unit)
    timer_service = "[Unit]\nDescription=DARK Backhaul scheduled restart (%i)\n\n[Service]\nType=oneshot\nExecStart=/bin/systemctl restart backhaul@%i.service\n"
    timer_unit = "[Unit]\nDescription=DARK Backhaul scheduled restart timer (%i)\n\n[Timer]\nOnUnitActiveSec=1h\nOnBootSec=1h\nAccuracySec=1min\nUnit=backhaul-restart@%i.service\n\n[Install]\nWantedBy=timers.target\n"
    Path("/etc/systemd/system/backhaul-restart@.service").write_text(timer_service)
    Path("/etc/systemd/system/backhaul-restart@.timer").write_text(timer_unit)
    override = Path(f"/etc/systemd/system/backhaul-restart@{name}.timer.d")
    if restart_every == "off":
        run(["systemctl", "disable", "--now", f"backhaul-restart@{name}.timer"], timeout=15)
        shutil.rmtree(override, ignore_errors=True)
    else:
        override.mkdir(parents=True, exist_ok=True)
        (override / "interval.conf").write_text(f"[Timer]\nOnUnitActiveSec=\nOnUnitActiveSec={restart_every}\nOnBootSec=\nOnBootSec={restart_every}\n")
    run(["systemctl", "daemon-reload"], timeout=20)
    firewall_rules: list[str] = []
    try:
        firewall_rules = _configure_ufw(tunnel_dir, name, role, transport, tunnel_port, ports)
        code, output = run(["systemctl", "enable", "--now", f"backhaul@{name}.service"], timeout=30)
        if code != 0:
            raise RuntimeError(f"Service start failed: {output[-1500:]}")
        if restart_every != "off":
            code, output = run(["systemctl", "enable", "--now", f"backhaul-restart@{name}.timer"], timeout=20)
            if code != 0:
                raise RuntimeError(f"Restart timer failed: {output[-1000:]}")
    except Exception:
        run(["systemctl", "disable", "--now", f"backhaul-restart@{name}.timer"], timeout=15)
        run(["systemctl", "disable", "--now", f"backhaul@{name}.service"], timeout=20)
        if shutil.which("ufw"):
            for rule in firewall_rules:
                run(["ufw", "--force", "delete", "allow", rule], timeout=20)
        shutil.rmtree(tunnel_dir, ignore_errors=True)
        raise
    service = f"backhaul@{name}.service"
    monitor = {"name": name, "method": "DARK Backhaul", "role": role, "service": service, "listen_port": tunnel_port if role == "server" else None, "user_ports": ports if role == "server" else [], "target_host": "127.0.0.1" if role == "server" else endpoint, "target_port": tunnel_port}
    config["tunnels"] = [item for item in config.setdefault("tunnels", []) if item.get("name") != name] + [monitor]
    for key in ("services", "managed_services"):
        if service not in config.setdefault(key, []):
            config[key].append(service)
    save_json(CONFIG_PATH, config)
    return f"DARK Backhaul deployed\nrole={role}\ntunnel={name}\nendpoint={endpoint}:{tunnel_port}\ntransport={transport}\nprofile={profile}\ncore={core_version}\nservice={service} active\nufw_rules={','.join(firewall_rules) if firewall_rules else 'not-needed'}"


def _remove_dark_backhaul(payload: dict[str, Any], config: dict[str, Any]) -> str:
    if payload.get("plugin_id") != "dark-backhaul":
        raise ValueError("Plugin is not allowlisted")
    name = str(payload.get("name", ""))
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,24}", name):
        raise ValueError("Invalid tunnel name")
    service = f"backhaul@{name}.service"
    timer = f"backhaul-restart@{name}.timer"
    run(["systemctl", "disable", "--now", timer], timeout=20)
    run(["systemctl", "disable", "--now", service], timeout=30)
    tunnel_dir = Path("/etc/dark-backhaul/tunnels") / name
    firewall_file = tunnel_dir / "ufw-created.json"
    if firewall_file.exists() and shutil.which("ufw"):
        try:
            for rule in json.loads(firewall_file.read_text()):
                if re.fullmatch(r"[0-9]{1,5}/(?:tcp|udp)", str(rule)):
                    run(["ufw", "--force", "delete", "allow", str(rule)], timeout=20)
        except (OSError, ValueError, TypeError):
            pass
    if tunnel_dir.parent == Path("/etc/dark-backhaul/tunnels"):
        shutil.rmtree(tunnel_dir, ignore_errors=True)
    shutil.rmtree(Path("/etc/systemd/system") / f"backhaul-restart@{name}.timer.d", ignore_errors=True)
    run(["systemctl", "daemon-reload"], timeout=20)
    config["tunnels"] = [item for item in config.get("tunnels", []) if item.get("name") != name]
    for key in ("services", "managed_services"):
        config[key] = [item for item in config.get(key, []) if item != service]
    save_json(CONFIG_PATH, config)
    return f"DARK Backhaul tunnel {name} removed from this node; shared core retained"


def execute_job(job: dict[str, Any], config: dict[str, Any]) -> tuple[str, str]:
    kind = str(job.get("kind", ""))
    payload = json.loads(job.get("payload") or "{}")
    if kind not in ALLOWED_JOB_KINDS:
        return "failed", "Job kind is not allowed"
    if kind == "diagnostics":
        commands = [
            ["systemctl", "--failed", "--no-pager"],
            ["ss", "-s"],
            ["ip", "route"],
            ["df", "-h", "/"],
        ]
        output = []
        for command in commands:
            code, text = run(command)
            output.append(f"$ {shlex.join(command)}\n{text.strip()}\n[exit={code}]")
        return "completed", "\n\n".join(output)
    if kind == "tunnel_test":
        tunnels = monitored_tunnels(config)
        if not tunnels:
            return "completed", "No tunnels are configured on this Agent"
        reports = asyncio.run(_collect_tunnel_reports(tunnels))
        return "completed", json.dumps(reports, indent=2)
    if kind == "logs":
        service = str(payload.get("service") or "dark-noc-agent.service")
        if service != "dark-noc-agent.service" and not restart_allowed(service, config):
            return "failed", "Service is not in managed_services allowlist"
        code, output = run(["journalctl", "-u", service, "-n", "200", "--no-pager", "-o", "short-iso"], timeout=15)
        return ("completed" if code == 0 else "failed"), output
    if kind == "plugin_deploy":
        try:
            return "completed", _deploy_dark_backhaul(payload, config)
        except Exception as exc:
            return "failed", f"DARK Backhaul deployment failed: {exc}"
    if kind == "plugin_remove":
        try:
            return "completed", _remove_dark_backhaul(payload, config)
        except Exception as exc:
            return "failed", f"DARK Backhaul removal failed: {exc}"
    if kind == "speed_test":
        target = config.get("speedtest", {})
        host, port = str(target.get("host", "")), int(target.get("port", 5201))
        if not host:
            return "failed", "Configure speedtest.host and speedtest.port in the Agent config"
        code, output = run(["iperf3", "-c", host, "-p", str(port), "-J", "-t", "5"], timeout=15)
        return ("completed" if code == 0 else "failed"), output
    if kind == "configure_autoheal":
        try:
            enabled = bool(payload.get("enabled"))
            cooldown = int(payload.get("cooldown_seconds", 300))
            maximum = int(payload.get("max_restarts_per_hour", 3))
            if not 60 <= cooldown <= 86400 or not 1 <= maximum <= 12:
                raise ValueError
        except (TypeError, ValueError):
            return "failed", "Invalid Auto-Heal policy"
        config["autoheal"] = {"enabled": enabled, "cooldown_seconds": cooldown, "max_restarts_per_hour": maximum}
        save_json(CONFIG_PATH, config)
        return "completed", f"Auto-Heal {'enabled' if enabled else 'disabled'}; cooldown={cooldown}s; hourly_limit={maximum}"
    service = str(payload.get("service", ""))
    if not service or not restart_allowed(service, config):
        return "failed", "Service is not in managed_services allowlist"
    if kind == "restart_service":
        code, output = run(["systemctl", "restart", service])
        return ("completed" if code == 0 else "failed"), output or f"{service} restarted"
    if kind == "service_status":
        code, output = run(["systemctl", "status", service, "--no-pager", "-l"])
        return ("completed" if code in {0, 3} else "failed"), output
    return "failed", "Unsupported job"


async def maybe_autoheal(config: dict[str, Any], reports: list[dict[str, Any]], state: dict[str, Any]) -> None:
    policy = config.get("autoheal", {})
    if not policy.get("enabled", False):
        return
    cooldown = max(int(policy.get("cooldown_seconds", 300)), 60)
    maximum = min(max(int(policy.get("max_restarts_per_hour", 3)), 1), 6)
    history = [float(ts) for ts in state.get("restart_history", []) if time.time() - float(ts) < 3600]
    for report in reports:
        if report["status"] != "down" or not report.get("service"):
            continue
        service = report["service"]
        last = float(state.get("last_restart", {}).get(service, 0))
        if not restart_allowed(service, config) or time.time() - last < cooldown or len(history) >= maximum:
            continue
        code, _ = run(["systemctl", "restart", service])
        if code == 0:
            now = time.time()
            state.setdefault("last_restart", {})[service] = now
            history.append(now)
    state["restart_history"] = history


async def process_jobs(jobs: list[dict[str, Any]], config: dict[str, Any], client: httpx.AsyncClient, hub: str) -> None:
    for job in jobs:
        execution = asyncio.create_task(asyncio.to_thread(execute_job, job, config))
        while not execution.done():
            done, _ = await asyncio.wait({execution}, timeout=60)
            if done:
                break
            lease = await client.post(f"{hub}/api/agent/jobs/{job['id']}/lease")
            lease.raise_for_status()
        status, output = await execution
        last_error: Exception | None = None
        for attempt in range(5):
            try:
                response = await client.post(f"{hub}/api/agent/jobs/result", json={"job_id": job["id"], "status": status, "output": output})
                response.raise_for_status()
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                await asyncio.sleep(min(2 ** attempt, 15))
        if last_error:
            raise last_error


async def main() -> None:
    config = load_json(CONFIG_PATH, {})
    required = ["hub_url", "agent_token"]
    if any(not config.get(key) for key in required):
        raise SystemExit(f"Missing required keys in {CONFIG_PATH}: {', '.join(required)}")
    hub = str(config["hub_url"]).rstrip("/")
    headers = {"Authorization": f"Bearer {config['agent_token']}"}
    verify_value = config.get("verify_tls", True)
    verify_tls: bool | str = verify_value if isinstance(verify_value, (bool, str)) else True
    interval = min(max(int(config.get("interval_seconds", 15)), 5), 60)
    state = load_json(STATE_PATH, {})
    timeout = httpx.Timeout(20, connect=10)
    async with httpx.AsyncClient(headers=headers, verify=verify_tls, timeout=timeout) as client:
        job_task: asyncio.Task | None = None
        while True:
            try:
                refresh_connection_snapshot()
                metrics = base_metrics(state.get("net", {}))
                state["net"] = {key: metrics[key] for key in ("bytes_recv", "bytes_sent", "ts")}
                reports = await _collect_tunnel_reports(monitored_tunnels(config))
                await maybe_autoheal(config, reports, state)
                payload = {"metrics": metrics, "services": service_reports(config), "tunnels": reports, "agent_version": VERSION, "autoheal": config.get("autoheal", {})}
                response = await client.post(f"{hub}/api/agent/heartbeat", json=payload)
                response.raise_for_status()
                if job_task is None or job_task.done():
                    if job_task is not None:
                        try:
                            job_task.result()
                        except Exception as exc:
                            state["last_job_error"] = str(exc)[:1000]
                    jobs_response = await client.get(f"{hub}/api/agent/jobs")
                    jobs_response.raise_for_status()
                    jobs = jobs_response.json()
                    if jobs:
                        job_task = asyncio.create_task(process_jobs(jobs, config, client, hub))
                state["last_success"] = time.time()
                state.pop("last_error", None)
            except Exception as exc:
                state["last_error"] = str(exc)[:1000]
            save_json(STATE_PATH, state)
            await asyncio.sleep(interval)


if __name__ == "__main__":
    asyncio.run(main())
