import importlib.util
import os
import sys
import tempfile
from pathlib import Path

from fastapi.testclient import TestClient


with tempfile.TemporaryDirectory(prefix="dark-noc-test-") as data_dir:
    os.environ["DARK_NOC_DATA"] = data_dir
    os.environ["DARK_NOC_ADMIN_PASSWORD"] = "TestPassword-1234"
    hub_dir = Path(__file__).resolve().parents[1] / "hub"
    sys.path.insert(0, str(hub_dir))
    import app

    with TestClient(app.app, base_url="https://testserver") as client:
        health = client.get("/healthz")
        assert health.status_code == 200 and health.json() == {"status": "ok", "version": "1.6.2"}
        assert health.headers["x-content-type-options"] == "nosniff"

        login = client.post("/api/auth/login", json={"username": "admin", "password": "TestPassword-1234"})
        assert login.status_code == 200

        account = client.put("/api/auth/account", json={
            "current_password": "TestPassword-1234", "username": "noc-owner"
        })
        assert account.status_code == 200 and account.json()["username"] == "noc-owner"

        node = client.post("/api/nodes", json={
            "name": "IR-TEST-01", "region": "Iran Edge", "role": "edge",
            "host": "127.0.0.1", "ssh_port": 22, "ssh_user": "root"
        })
        assert node.status_code == 201
        token = node.json()["agent_token"]

        report = client.post("/api/agent/heartbeat", headers={"Authorization": f"Bearer {token}"}, json={
            "agent_version": "test", "metrics": {
                "cpu": 12, "ram": 34, "swap": 0, "disk": 20, "load1": 0.2,
                "rx_bps": 1000000, "tx_bps": 500000, "uptime": 5000, "connections": 42
            }, "services": [{"name": "backhaul@test-link.service", "status": "active"}], "autoheal": {"enabled": True, "cooldown_seconds": 300, "max_restarts_per_hour": 3},
            "tunnels": [{
                "name": "test-link", "method": "DARK Backhaul", "target": "127.0.0.1:443",
                "service": "backhaul@test-link.service", "listen_port": 443, "status": "healthy",
                "latency_ms": 62, "packet_loss": 0, "sessions": 21
            }, {"name": "must-be-ignored", "method": "PAQET", "target": "127.0.0.1:9999", "service": "paqet.service", "status": "healthy"}]
        })
        assert report.status_code == 200

        dashboard = client.get("/api/dashboard").json()
        assert dashboard["nodes"]["online"] == 1
        assert dashboard["connections"] == 42
        assert dashboard["rx_bps"] == 1000000 and dashboard["tx_bps"] == 500000
        traffic = client.get("/api/dashboard/traffic?minutes=60")
        assert traffic.status_code == 200 and traffic.json()[-1]["rx_bps"] == 1000000
        tunnel_rows = client.get("/api/tunnels").json()
        assert len(tunnel_rows) == 1 and tunnel_rows[0]["node_host"] == "127.0.0.1"
        live_node = client.get("/api/nodes").json()[0]
        assert live_node["services"][0]["status"] == "active" and live_node["autoheal_enabled"] == 1
        updated = client.put("/api/nodes/1", json={
            "name": "IR-TEST-01", "region": "Iran Edge", "role": "edge",
            "host": "127.0.0.1", "ssh_port": 2222, "ssh_user": "root"
        })
        assert updated.status_code == 200 and updated.json()["ssh_pin_reset"] is True

        job = client.post("/api/nodes/1/jobs", json={"kind": "diagnostics"})
        assert job.status_code == 202
        jobs = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {token}"}).json()
        assert len(jobs) == 1 and jobs[0]["kind"] == "diagnostics"
        assert client.post(f"/api/agent/jobs/{jobs[0]['id']}/lease", headers={"Authorization": f"Bearer {token}"}).status_code == 200
        result = client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {token}"}, json={"job_id": jobs[0]["id"], "status": "completed", "output": "ok"})
        assert result.status_code == 200
        duplicate_result = client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {token}"}, json={"job_id": jobs[0]["id"], "status": "completed", "output": "ok"})
        assert duplicate_result.status_code == 200 and duplicate_result.json()["idempotent"] is True

        plugins = client.get("/api/plugins")
        assert plugins.status_code == 200 and plugins.json()[0]["id"] == "dark-backhaul"
        exit_node = client.post("/api/nodes", json={
            "name": "DE-TEST-01", "region": "Global Exit", "role": "exit",
            "host": "198.51.100.20", "ssh_port": 22, "ssh_user": "root"
        })
        exit_token = exit_node.json()["agent_token"]
        exit_report = client.post("/api/agent/heartbeat", headers={"Authorization": f"Bearer {exit_token}"}, json={
            "agent_version": "test", "metrics": {"cpu": 1, "ram": 2, "disk": 3}, "tunnels": []
        })
        assert exit_report.status_code == 200
        wrong_endpoint = client.post("/api/plugins/dark-backhaul/deploy", json={
            "name": "wrong-link", "iran_node_id": 1, "kharej_node_id": 2,
            "iran_endpoint": "203.0.113.10", "tunnel_port": 3080,
            "user_ports": [443], "transport": "tcpmux", "profile": "balanced", "restart_every": "off"
        })
        assert wrong_endpoint.status_code == 422
        deployment = client.post("/api/plugins/dark-backhaul/deploy", json={
            "name": "test-link", "iran_node_id": 1, "kharej_node_id": 2,
            "iran_endpoint": "127.0.0.1", "tunnel_port": 3080,
            "user_ports": [443, 8443], "transport": "tcpmux", "profile": "balanced",
            "restart_every": "off"
        })
        assert deployment.status_code == 202 and set(deployment.json()["jobs"]) == {"iran", "kharej"}
        deployments = client.get("/api/plugin-deployments").json()
        assert len(deployments) == 1 and deployments[0]["status"] == "queued"
        iran_plugin_jobs = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {token}"}).json()
        kharej_plugin_jobs = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {exit_token}"}).json()
        assert iran_plugin_jobs[0]["kind"] == "plugin_deploy"
        assert kharej_plugin_jobs[0]["kind"] == "plugin_deploy"
        assert client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {token}"}, json={"job_id": iran_plugin_jobs[0]["id"], "status": "failed", "output": "network error"}).status_code == 200
        assert client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {exit_token}"}, json={"job_id": kharej_plugin_jobs[0]["id"], "status": "failed", "output": "network error"}).status_code == 200
        assert client.get("/api/plugin-deployments").json()[0]["status"] == "failed"
        retry = client.post("/api/plugin-deployments/1/retry")
        assert retry.status_code == 202 and set(retry.json()["jobs"]) == {"iran", "kharej"}
        retry_iran = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {token}"}).json()[0]
        retry_kharej = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {exit_token}"}).json()[0]
        assert client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {token}"}, json={"job_id": retry_iran["id"], "status": "completed", "output": "ok"}).status_code == 200
        assert client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {exit_token}"}, json={"job_id": retry_kharej["id"], "status": "completed", "output": "ok"}).status_code == 200
        assert client.get("/api/plugin-deployments").json()[0]["status"] == "completed"
        removal = client.post("/api/plugin-deployments/1/remove")
        assert removal.status_code == 202
        remove_iran = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {token}"}).json()[0]
        remove_kharej = client.get("/api/agent/jobs", headers={"Authorization": f"Bearer {exit_token}"}).json()[0]
        assert remove_iran["kind"] == "plugin_remove" and remove_kharej["kind"] == "plugin_remove"
        assert client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {token}"}, json={"job_id": remove_iran["id"], "status": "completed", "output": "removed"}).status_code == 200
        assert client.post("/api/agent/jobs/result", headers={"Authorization": f"Bearer {exit_token}"}, json={"job_id": remove_kharej["id"], "status": "completed", "output": "removed"}).status_code == 200
        assert client.get("/api/plugin-deployments").json()[0]["status"] == "removed"

        failing_telemetry = {
            "agent_version": "test", "metrics": {"cpu": 2, "ram": 3, "disk": 4},
            "tunnels": [{"name": "test-link", "method": "DARK Backhaul", "target": "127.0.0.1:443", "service": "backhaul@test-link.service", "status": "down", "packet_loss": 100, "checks": {"process": False, "path": False}}]
        }
        assert client.post("/api/agent/heartbeat", headers={"Authorization": f"Bearer {token}"}, json=failing_telemetry).status_code == 200
        assert not [item for item in client.get("/api/incidents").json() if item["status"] == "open"]
        assert client.post("/api/agent/heartbeat", headers={"Authorization": f"Bearer {token}"}, json=failing_telemetry).status_code == 200
        active_incidents = [item for item in client.get("/api/incidents").json() if item["status"] == "open"]
        assert len(active_incidents) == 1
        assert client.post(f"/api/incidents/{active_incidents[0]['id']}/action", json={"action": "acknowledge"}).status_code == 200
        assert any(item["status"] == "acknowledged" for item in client.get("/api/incidents").json())

        # A heartbeat is authoritative: definitions no longer reported by an Agent are removed.
        empty_report = client.post("/api/agent/heartbeat", headers={"Authorization": f"Bearer {token}"}, json={
            "agent_version": "test", "metrics": {"cpu": 2, "ram": 3, "disk": 4}, "tunnels": []
        })
        assert empty_report.status_code == 200
        assert client.get("/api/tunnels").json() == []

        for _ in range(5):
            assert client.post("/api/auth/login", json={"username": "admin", "password": "wrong"}).status_code == 401
        assert client.post("/api/auth/login", json={"username": "admin", "password": "wrong"}).status_code == 429

print("DARK NOC smoke test passed")
