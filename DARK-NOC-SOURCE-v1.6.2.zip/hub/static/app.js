const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];
const viewTitles = { overview: 'Network Command', servers: 'Server Fleet', tunnels: 'Tunnel Matrix', incidents: 'Incident Command', terminal: 'SSH Command' };
let state = { nodes: [], tunnels: [], incidents: [], plugins: [], deployments: [], traffic: [], sockets: new Map(), selectedNode: null, nodeFilter: 'all', editingNode: null };
let refreshInFlight = false;
let liveSocket = null;

function esc(value) {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  if (response.status === 401) {
    $('#login-gate').classList.remove('hidden');
    throw new Error('Authentication required');
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Request failed (${response.status})`);
  return payload;
}

function bytesPerSecond(value) {
  const n = Number(value || 0);
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)} Gb/s`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(0)} Mb/s`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(0)} Kb/s`;
  return `${n.toFixed(0)} b/s`;
}

function relativeTime(timestamp) {
  if (!timestamp) return 'never';
  const seconds = Math.max(0, Math.floor(Date.now() / 1000 - timestamp));
  if (seconds < 10) return 'now';
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

function duration(timestamp) {
  const total=Math.max(0,Math.floor(Date.now()/1000-Number(timestamp||Date.now()/1000)));
  const hours=Math.floor(total/3600), minutes=Math.floor(total%3600/60), seconds=total%60;
  return [hours,minutes,seconds].map(value=>String(value).padStart(2,'0')).join(':');
}

function switchView(name) {
  if (!viewTitles[name]) return;
  $$('.view').forEach(view => view.classList.toggle('active', view.id === `view-${name}`));
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.view === name));
  $('#view-title').textContent = viewTitles[name];
  $('#sidebar').classList.remove('open');
  scrollTo({ top: 0, behavior: 'smooth' });
}

function showToast(title, message, error = false) {
  const toast = $('#toast');
  toast.innerHTML = `<span>${error ? '!' : '✓'}</span><p><strong>${esc(title)}</strong><small>${esc(message)}</small></p>`;
  toast.style.borderColor = error ? 'rgba(255,65,93,.35)' : '';
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 3600);
}

function openModal(selector) {
  const modal = $(selector);
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  setTimeout(() => $('input', modal)?.focus(), 60);
}

function closeModal(modal) {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
}

function resource(label, value, warning = false, display = `${Number(value || 0).toFixed(0)}%`) {
  return `<div class="resource ${warning ? 'warn' : ''}"><div><span>${label}</span><b>${display}</b></div><span><i style="width:${Math.min(Number(value || 0),100)}%"></i></span></div>`;
}

function renderNodes() {
  const target = $('#server-grid');
  if (!state.nodes.length) {
    target.innerHTML = '<div class="empty-state"><strong>No server has been enrolled</strong>Add your first node to start receiving live telemetry.</div>';
    return;
  }
  const visibleNodes = state.nodeFilter === 'all' ? state.nodes : state.nodes.filter(node => node.status !== 'online');
  if (!visibleNodes.length) {
    target.innerHTML = '<div class="empty-state"><strong>No nodes match this filter</strong>All registered nodes are currently healthy.</div>';
    return;
  }
  target.innerHTML = visibleNodes.map(node => {
    const m = node.metric || {};
    const watch = node.status !== 'online' || Number(m.cpu) > 80 || Number(m.ram) > 85;
    const throughput = Number(m.rx_bps || 0) + Number(m.tx_bps || 0);
    const tunnels = state.tunnels.filter(t => t.node_id === node.id);
    const healthy = tunnels.filter(t => t.status === 'healthy').length;
    const services = (node.services || []).map(service=>`<button class="service-chip ${service.status==='active'?'':'service-down'}" data-service-node="${node.id}" data-service-name="${esc(service.name)}" title="Restart ${esc(service.name)}"><i></i>${esc(service.name)} · ${esc(service.status)}</button>`).join('');
    const code = node.region.toUpperCase().includes('IRAN') ? 'IR' : node.name.slice(0,2).toUpperCase();
    return `<article class="panel server-card">
      <div class="server-head"><div class="server-id"><span class="flag">${esc(code)}</span><div><strong>${esc(node.name)}</strong><small>${esc(node.region)} · ${esc(node.host)} · AGENT ${esc(node.agent_version||'PENDING')} · AUTO-HEAL ${node.autoheal_enabled?'ON':'OFF'}</small></div></div><span class="status-label ${watch ? 'watch' : ''}">● ${esc(node.status.toUpperCase())}</span></div>
      <div class="resource-grid">${resource('CPU',m.cpu,Number(m.cpu)>80)}${resource('RAM',m.ram,Number(m.ram)>85)}${resource('DISK',m.disk,Number(m.disk)>85)}${resource('LOAD',Math.min(Number(m.load1||0)*10,100),false,Number(m.load1||0).toFixed(2))}</div>
      <div class="service-list">${services || '<span>No managed services reported</span>'}</div>
      <div class="server-bottom"><div><span>TUNNELS</span><b>${healthy} / ${tunnels.length}</b></div><div><span>LAST SEEN</span><b>${relativeTime(node.last_seen)}</b></div><div class="server-actions"><button class="square-action server-ssh" title="Open SSH" data-node-id="${node.id}">›_</button><button class="square-action node-diagnostics" title="Diagnostics" data-node-id="${node.id}">⌁</button><button class="square-action node-logs" title="Agent logs" data-node-id="${node.id}">LOG</button><button class="square-action node-autoheal" title="Toggle Auto-Heal" data-node-id="${node.id}">AH</button><button class="square-action node-edit" title="Edit node" data-node-id="${node.id}">EDT</button><button class="square-action node-token" title="Rotate Agent token" data-node-id="${node.id}">TOK</button><button class="square-action node-pin" title="Reset SSH fingerprint" data-node-id="${node.id}">KEY</button><button class="square-action node-delete" title="Delete node" data-node-id="${node.id}" data-node-name="${esc(node.name)}">×</button></div></div>
    </article>`;
  }).join('');
}

function renderTunnels() {
  const target = $('#tunnel-rows');
  if (!state.tunnels.length) {
    target.innerHTML = '<div class="empty-state"><strong>No DARK Backhaul telemetry yet</strong>Deploy a tunnel from the verified plugin above.</div>';
    return;
  }
  target.innerHTML = state.tunnels.map((tunnel, index) => {
    const status = (tunnel.status || 'unknown').toUpperCase();
    const unhealthy = status !== 'HEALTHY';
    const tunnelRate = tunnel.rx_bps == null && tunnel.tx_bps == null ? '—' : bytesPerSecond(Number(tunnel.rx_bps||0)+Number(tunnel.tx_bps||0));
    const statusClass=status==='DOWN'?'down':unhealthy?'degraded':'';
    return `<div class="table-row" role="row"><div class="route-name"><span>${esc((tunnel.region || 'NO').slice(0,2).toUpperCase())}</span><p><strong>${esc(tunnel.name)}</strong><small>${esc(tunnel.node_name)} <code class="node-ip">${esc(tunnel.node_host || 'IP N/A')}</code> → ${esc(tunnel.target || 'local')}</small></p></div><span><em class="method-pill">${esc(tunnel.method || 'DARK Backhaul')}</em></span><span>${tunnel.latency_ms == null ? '—' : `${Number(tunnel.latency_ms).toFixed(1)} ms`}</span><span class="${status==='DOWN' ? 'red' : unhealthy ? 'amber' : ''}">${tunnel.packet_loss == null ? '—' : `${Number(tunnel.packet_loss).toFixed(1)}%`}</span><span>${tunnelRate}</span><span>${Number(tunnel.sessions || 0)}</span><span class="table-status ${statusClass}">${esc(status)}</span><span class="row-actions"><button class="row-menu tunnel-restart" data-node-id="${Number(tunnel.node_id)}" data-service="${esc(tunnel.service||'')}" title="Restart service">↻</button></span></div>`;
  }).join('');
}

function renderPlugins() {
  const grid = $('#plugin-grid');
  grid.innerHTML = state.plugins.map(plugin => `<article class="panel plugin-card">
    <div class="plugin-icon">DB</div><div class="plugin-copy"><div class="plugin-title"><h3>${esc(plugin.name)}</h3><span>v${esc(plugin.version)}</span></div><p>${esc(plugin.description)}</p>
    <div class="plugin-tags">${plugin.transports.map(item=>`<span>${esc(item.toUpperCase())}</span>`).join('')}</div>
    <div class="plugin-meta"><span>IRAN <b>SERVER</b></span><i>→</i><span>KHAREJ <b>CLIENT</b></span><em>ALLOWLISTED</em></div></div>
    <button class="primary-btn plugin-deploy" data-plugin-id="${esc(plugin.id)}">INSTALL & CREATE</button>
  </article>`).join('') || '<div class="empty-state"><strong>No plugins available</strong>The local catalog is empty.</div>';
  const strip = $('#deployment-strip');
  strip.innerHTML = state.deployments.slice(0,5).map(item => `<article class="deployment ${esc(item.status)}"><span class="deployment-pulse"></span><div><strong>${esc(item.name)}</strong><small>${esc(item.iran_node)} → ${esc(item.kharej_node)}</small></div><div class="deploy-side"><span>IRAN</span><b>${esc(item.iran_status || 'queued')}</b></div><div class="deploy-side"><span>KHAREJ</span><b>${esc(item.kharej_status || 'queued')}</b></div><em>${esc(item.status.toUpperCase().replaceAll('_',' '))}</em><span class="deployment-actions">${['failed','rolled_back','rollback_failed'].includes(item.status)?`<button class="deploy-retry" data-deployment-id="${Number(item.id)}">RETRY</button>`:''}${item.status==='completed'?`<button class="deploy-remove" data-deployment-id="${Number(item.id)}">REMOVE</button>`:''}</span></article>`).join('');
}

function renderIncidents() {
  const open = state.incidents.filter(item => ['open','acknowledged'].includes(item.status));
  $$('.nav-item b.danger').forEach(item => item.textContent = open.length);
  const active = open[0];
  const detail = $('.incident-detail');
  if (!active) {
    if(detail){$('.severity-pill',detail).textContent='NO ACTIVE INCIDENT';$('.severity-pill',detail).style.color='var(--green)';$('h2',detail).textContent='All monitored paths are operational';$('p',detail).textContent='DARK NOC is watching every enrolled tunnel.';$('.downtime strong',detail).textContent='00:00:00';$('.diagnostic-grid',detail).innerHTML='<div class="diag ok"><span>✓</span><strong>LIVE STATE</strong><small>No failed checks</small></div>';$('.remediation',detail).innerHTML='<div><span class="live-dot"></span><p><strong>Monitoring active</strong><small>Waiting for the next Agent heartbeat</small></p></div>';}
    const timeline=$('.timeline-panel .timeline');if(timeline)timeline.innerHTML='<div class="active"><time>NOW</time><span></span><p><strong>No active recovery timeline</strong><small>Resolved incidents remain available in exported history.</small></p></div>';
    return;
  }
  if (detail) {
    let telemetry={};try{telemetry=JSON.parse(active.detail||'{}')}catch{}
    $('h2', detail).textContent = active.title;
    $('p', detail).textContent = `${active.node_name || 'Unknown node'} · ${active.tunnel_name || 'Node incident'}`;
    $('.severity-pill',detail).textContent=`${String(active.severity||'warning').toUpperCase()} · ACTIVE`;$('.severity-pill',detail).style.color='';
    $('.downtime strong',detail).textContent=duration(active.opened_at);
    const checks=telemetry.checks||{};
    $('.diagnostic-grid',detail).innerHTML=`<div class="diag ${checks.process?'ok':'fail'}"><span>01</span><strong>PROCESS</strong><small>${checks.process?'Service active':'Service failed'}</small></div><div class="diag ${checks.path?'ok':'fail'}"><span>02</span><strong>TUNNEL PATH</strong><small>${telemetry.latency_ms==null?'No response':`${Number(telemetry.latency_ms).toFixed(1)} ms`}</small></div><div class="diag ${Number(telemetry.packet_loss||0)>0?'fail':'ok'}"><span>03</span><strong>PACKET LOSS</strong><small>${Number(telemetry.packet_loss||0).toFixed(1)}%</small></div><div class="diag waiting"><span>04</span><strong>AGENT</strong><small>Last report ${relativeTime(telemetry.last_check||active.opened_at)}</small></div>`;
    $('.remediation',detail).innerHTML=`<div><span class="spinner"></span><p><strong>${active.status==='acknowledged'?'Incident acknowledged':'Operator attention required'}</strong><small>Incident opened ${relativeTime(active.opened_at)}</small></p></div><span class="incident-command-buttons">${active.status==='open'?`<button class="ghost-btn incident-ack" data-incident-id="${Number(active.id)}">ACKNOWLEDGE</button>`:''}<button class="ghost-btn incident-resolve" data-incident-id="${Number(active.id)}">RESOLVE</button><button class="danger-btn" id="take-control" data-node-id="${Number(active.node_id)}">OPEN SSH</button></span>`;
  }
  const timeline=$('.timeline-panel .timeline');if(timeline)timeline.innerHTML=`<div class="active"><time>${new Date(active.opened_at*1000).toLocaleTimeString('en-GB')}</time><span></span><p><strong>${esc(active.title)}</strong><small>Detected by ${esc(active.node_name||'Agent')}</small></p></div>`;
}

function renderLiveTopology() {
  const topology = $('#topology');
  const nodes = state.nodes.slice(0, 12);
  topology.innerHTML = `<div class="grid-floor" aria-hidden="true"></div><div class="live-topology-grid">${nodes.map(node=>{
    const tunnels=state.tunnels.filter(item=>item.node_id===node.id), bad=tunnels.filter(item=>item.status!=='healthy').length;
    return `<button class="live-node server-ssh" data-node-id="${Number(node.id)}"><span class="node-pulse ${node.status==='online'?(bad?'amber':'green'):'red'}"></span><i>${esc(node.role==='edge'?'IR':node.role==='exit'?'EX':'HB')}</i><strong>${esc(node.name)}</strong><small>${esc(node.region)} · ${tunnels.length} tunnel${tunnels.length===1?'':'s'}</small></button>`;
  }).join('') || '<div class="empty-state"><strong>No live nodes</strong>Enroll an Agent to build the topology.</div>'}</div>`;
}

function renderLiveIncident() {
  const panel=$('.incident-panel'), active=state.incidents.find(item=>['open','acknowledged'].includes(item.status));
  if(!active){panel.innerHTML='<div class="panel-head compact"><div><span class="panel-kicker">INCIDENT FEED</span><h2>All clear</h2></div><button class="text-btn" data-jump="incidents">VIEW ALL</button></div><div class="empty-state compact-empty"><strong>No active incidents</strong>Every reporting path is currently healthy.</div>';return;}
  panel.innerHTML=`<div class="panel-head compact"><div><span class="panel-kicker">INCIDENT FEED</span><h2>Requires attention</h2></div><button class="text-btn" data-jump="incidents">VIEW ALL</button></div><article class="incident critical"><div class="incident-top"><span>${esc(active.status==='acknowledged'?'ACKNOWLEDGED':active.severity.toUpperCase())}</span><time>${relativeTime(active.opened_at)}</time></div><h3>${esc(active.title)}</h3><p>${esc(active.node_name||'Unknown node')} → ${esc(active.tunnel_name||'Node')}</p><div class="incident-actions"><button class="ghost-btn incident-ack" data-incident-id="${Number(active.id)}">ACK</button><button class="ghost-btn incident-resolve" data-incident-id="${Number(active.id)}">RESOLVE</button><button class="danger-btn" id="take-control" data-node-id="${Number(active.node_id)}">SSH</button></div></article>`;
}

function renderNodeHealth() {
  const panel=$('.node-health');
  panel.innerHTML='<div class="panel-head compact"><div><span class="panel-kicker">NODE HEALTH</span><h2>Resource pressure</h2></div><button class="text-btn" data-jump="servers">DETAILS</button></div>'+state.nodes.slice(0,5).map(node=>{const m=node.metric||{},pressure=Math.max(Number(m.cpu||0),Number(m.ram||0),Number(m.disk||0)),watch=node.status!=='online'||pressure>=80;return `<div class="health-row"><div><span class="flag">${esc(node.role==='edge'?'IR':node.role==='exit'?'EX':'HB')}</span><p><strong>${esc(node.name)}</strong><small>CPU ${Number(m.cpu||0).toFixed(0)}% · RAM ${Number(m.ram||0).toFixed(0)}% · DISK ${Number(m.disk||0).toFixed(0)}%</small></p></div><span class="bar ${watch?'amber':''}"><i style="width:${Math.min(pressure,100)}%"></i></span><b class="${watch?'warning-text':'ok'}">${node.status!=='online'?'OFFLINE':watch?'WATCH':'GOOD'}</b></div>`;}).join('');
}

function renderTrafficChart() {
  const values=state.traffic.map(point=>Number(point.rx_bps||0)+Number(point.tx_bps||0));
  const yLabels=$$('.chart-wrap .y-axis span'), xLabels=$$('.chart-wrap .x-axis span');
  if(!values.length){$('#traffic-line').setAttribute('d','M0 200 L900 200');$('#traffic-area').setAttribute('d','M0 200 L900 200 L900 210 L0 210Z');yLabels.forEach((label,index)=>label.textContent=index===4?'0':'—');xLabels.forEach((label,index)=>label.textContent=index===4?'NOW':'—');return;}
  const max=Math.max(...values,1), step=values.length===1?900:900/(values.length-1);
  const points=values.length===1?[`0 ${(200-(values[0]/max)*175).toFixed(1)}`,`900 ${(200-(values[0]/max)*175).toFixed(1)}`]:values.map((value,index)=>`${(index*step).toFixed(1)} ${(200-(value/max)*175).toFixed(1)}`);
  const line=`M${points.join(' L')}`; $('#traffic-line').setAttribute('d',line); $('#traffic-area').setAttribute('d',`${line} L900 210 L0 210Z`);
  [1,.75,.5,.25,0].forEach((factor,index)=>{if(yLabels[index])yLabels[index].textContent=factor?bytesPerSecond(max*factor).replace('/s',''): '0';});
  [0,.25,.5,.75,1].forEach((factor,index)=>{if(!xLabels[index])return;const point=state.traffic[Math.min(Math.round((state.traffic.length-1)*factor),state.traffic.length-1)];xLabels[index].textContent=index===4?'NOW':new Date(Number(point.ts)*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});});
}

function updateOverview(summary) {
  const online = Number(summary.nodes.online || 0);
  const total = Object.values(summary.nodes).reduce((a,b) => a + Number(b), 0);
  const health = Number(summary.health_percent || 0).toFixed(1);
  $('.accent-green .stat-value strong').textContent = health;
  $('#throughput').textContent = bytesPerSecond(summary.throughput_bps).replace(/\s.*$/,'');
  $('.accent-blue .stat-value small').textContent = bytesPerSecond(summary.throughput_bps).split(' ').slice(1).join(' ');
  $('#sessions').textContent = Number(summary.connections || 0).toLocaleString();
  $('#throughput-detail').textContent=`↓ ${bytesPerSecond(summary.rx_bps)} / ↑ ${bytesPerSecond(summary.tx_bps)}`;
  const unhealthyTunnels=Object.entries(summary.tunnels||{}).filter(([status])=>status!=='healthy').reduce((sum,[,count])=>sum+Number(count),0);
  $('#health-detail').textContent=`${online}/${total} agents · ${unhealthyTunnels} tunnel alerts`;
  $('#health-state').textContent=health==='100.0'?'OPERATIONAL':online?'DEGRADED':'NO AGENTS';
  $('#session-nodes').textContent=`${online} LIVE NODE${online===1?'':'S'}`;
  $('#agent-count').textContent=`${online} / ${total}`;
  $('#chart-throughput').textContent=bytesPerSecond(summary.throughput_bps);
  $('.accent-red .stat-value strong').textContent = String(summary.open_incidents || 0).padStart(2,'0');
  $('#connection-banner').innerHTML = '<span class="live-source">LIVE HUB CONNECTED</span> Telemetry and incident data are updating automatically.';
  $$('.nav-item')[1]?.querySelector('b') && ($$('.nav-item')[1].querySelector('b').textContent = total);
  $$('.nav-item')[2]?.querySelector('b') && ($$('.nav-item')[2].querySelector('b').textContent = state.tunnels.length);
  const footer=$$('.topology-footer b');if(footer.length>=3){footer[0].textContent=online;footer[1].textContent=state.nodes.filter(node=>node.status==='online'&&state.tunnels.some(t=>t.node_id===node.id&&t.status!=='healthy')).length;footer[2].textContent=state.nodes.filter(node=>node.status==='offline').length;}
}

async function refresh() {
  if (refreshInFlight) return;
  refreshInFlight = true;
  try {
    const [summary,nodes,tunnels,incidents,plugins,deployments,traffic] = await Promise.all([api('/api/dashboard'),api('/api/nodes'),api('/api/tunnels'),api('/api/incidents'),api('/api/plugins'),api('/api/plugin-deployments'),api('/api/dashboard/traffic?minutes=60')]);
    state = { ...state, nodes, tunnels, incidents, plugins, deployments, traffic };
    renderNodes(); renderTunnels(); renderPlugins(); renderIncidents(); renderLiveTopology(); renderLiveIncident(); renderNodeHealth(); renderTrafficChart(); updateOverview(summary);
    $('#sync-time').textContent = 'NOW';
  } catch (error) {
    if (error.message !== 'Authentication required') {
      $('#connection-banner').innerHTML = '<span class="offline-source">HUB CONNECTION LOST</span> Retrying automatically.';
    }
  } finally {
    refreshInFlight = false;
  }
}

async function createJob(nodeId, kind, service = null, payload = {}, showOutput = false) {
  const job = await api(`/api/nodes/${nodeId}/jobs`, { method:'POST', body:JSON.stringify({kind,service,payload}) });
  showToast('COMMAND QUEUED', `Job #${job.job_id} will run through the secure Agent channel.`);
  if (showOutput) waitForJob(job.job_id);
  return job;
}

async function waitForJob(jobId) {
  $('#job-output').textContent = `Waiting for Agent to execute job #${jobId}…`;
  openModal('#output-modal');
  for (let attempt = 0; attempt < 180; attempt += 1) {
    await new Promise(resolve => setTimeout(resolve, 1500));
    try {
      const job = await api(`/api/jobs/${jobId}`);
      if (job.status === 'completed' || job.status === 'failed') {
        $('#output-title').textContent = `${job.kind} · ${job.status.toUpperCase()}`;
        $('#job-output').textContent = job.output || 'Command completed without output.';
        return;
      }
      $('#job-output').textContent = `Job #${jobId}\nStatus: ${job.status}\nWaiting for Agent response…`;
    } catch (error) { $('#job-output').textContent = error.message; return; }
  }
  $('#job-output').textContent = 'No terminal result after 4.5 minutes. The job may still be running; check Remote job history.';
}

function closeSocket(slot) {
  const socket = state.sockets.get(slot);
  if (socket) { clearInterval(socket.keepaliveTimer); socket.close(); }
  state.sockets.delete(slot);
}

function connectSSH(nodeId, slot = null) {
  const node = state.nodes.find(item => item.id === Number(nodeId));
  if (!node) return;
  if (!slot) {
    const first=state.sockets.get('terminal-iran'), second=state.sockets.get('terminal-germany');
    slot=!first||first.readyState>=WebSocket.CLOSING?'terminal-iran':(!second||second.readyState>=WebSocket.CLOSING?'terminal-germany':'terminal-iran');
  }
  switchView('terminal');
  closeSocket(slot);
  const screen = $(`#${slot}`);
  const card=screen.closest('.terminal-card'), code=node.role==='edge'?'IR':node.role==='exit'?'EX':'HB';
  $('.terminal-server .flag',card).textContent=code;
  $('.terminal-server strong',card).textContent=node.name;
  $('.terminal-server small',card).textContent=`${node.ssh_user}@${node.host}:${node.ssh_port}`;
  $('.terminal-input span',card).textContent=`${node.ssh_user}@${node.name}:~#`;
  $$('.terminal-card').forEach(item=>item.classList.remove('active-terminal'));
  card.classList.add('active-terminal');
  $('.ssh-online',card).textContent='● CONNECTING';
  screen.innerHTML = `<div class="term-line dim">Connecting securely to ${esc(node.name)} (${esc(node.host)}:${Number(node.ssh_port)})…</div>`;
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const socket = new WebSocket(`${protocol}//${location.host}/ws/ssh/${node.id}`);
  state.sockets.set(slot, socket);
  state.selectedNode = node.id;
  socket.onmessage = event => {
    const message = JSON.parse(event.data);
    if (message.type === 'output') screen.insertAdjacentText('beforeend', message.data);
    if (message.type === 'connected') { $('.ssh-online',card).textContent='● CONNECTED'; screen.insertAdjacentHTML('beforeend', `<div class="term-line green">✓ SSH connected to ${esc(message.node)}</div><div class="term-line dim">Pinned host key: ${esc(message.fingerprint||'unavailable')}</div>`); }
    if (message.type === 'error') { $('.ssh-online',card).textContent='● ERROR'; screen.insertAdjacentHTML('beforeend', `<div class="term-line red">${esc(message.message)}</div>`); }
    screen.scrollTop = screen.scrollHeight;
  };
  socket.onopen = () => { socket.keepaliveTimer=setInterval(()=>{if(socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify({type:'ping'}));},25000); };
  socket.onerror = () => { $('.ssh-online',card).textContent='● ERROR'; screen.insertAdjacentHTML('beforeend','<div class="term-line red">SSH WebSocket connection failed.</div>'); };
  socket.onclose = () => { clearInterval(socket.keepaliveTimer); $('.ssh-online',card).textContent='● CLOSED'; screen.insertAdjacentHTML('beforeend','<div class="term-line dim">\nSession closed.</div>'); };
}

$('#login-form').addEventListener('submit', async event => {
  event.preventDefault();
  const form = new FormData(event.target);
  $('#login-error').textContent = '';
  try {
    const session=await api('/api/auth/login',{method:'POST',body:JSON.stringify({username:form.get('username'),password:form.get('password')})});
    $('#login-gate').classList.add('hidden');
    $('.operator strong').textContent=session.username;
    connectLive();
    event.target.reset();
    await refresh();
  } catch (error) { $('#login-error').textContent = error.message; }
});

async function boot() {
  try { const me=await api('/api/auth/me'); $('.operator strong').textContent=me.username; $('#login-gate').classList.add('hidden'); await refresh(); connectLive(); }
  catch { $('#login-gate').classList.remove('hidden'); }
}

function connectLive(){
  if(liveSocket&&liveSocket.readyState<WebSocket.CLOSING)return;
  const protocol=location.protocol==='https:'?'wss:':'ws:';
  liveSocket=new WebSocket(`${protocol}//${location.host}/ws/live`);
  liveSocket.onopen=()=>{liveSocket.keepaliveTimer=setInterval(()=>{if(liveSocket?.readyState===WebSocket.OPEN)liveSocket.send('ping');},25000);};
  liveSocket.onmessage=event=>{let message={};try{message=JSON.parse(event.data)}catch{}if(message.type==='telemetry'){clearTimeout(connectLive.refreshTimer);connectLive.refreshTimer=setTimeout(refresh,250);}};
  liveSocket.onclose=()=>{clearInterval(liveSocket?.keepaliveTimer);liveSocket=null;if($('#login-gate').classList.contains('hidden'))setTimeout(connectLive,3000);};
}

$$('.nav-item').forEach(button => button.addEventListener('click',()=>switchView(button.dataset.view)));
$('#menu-toggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
function openNewNode(){state.editingNode=null;$('#node-title').textContent='Add secure node';$('#node-form').reset();$('#node-form [name="ssh_port"]').value='22';$('#node-form [name="ssh_user"]').value='root';openModal('#node-modal');}
$('#add-node').addEventListener('click',openNewNode);
$$('[data-add-node]').forEach(button=>button.addEventListener('click',openNewNode));
$('.modal-cancel').addEventListener('click',()=>closeModal($('#node-modal')));
$$('.plugin-close,.plugin-cancel').forEach(button=>button.addEventListener('click',()=>closeModal($('#plugin-modal'))));
$$('.output-close').forEach(button=>button.addEventListener('click',()=>closeModal($('#output-modal'))));
$$('.account-close').forEach(button=>button.addEventListener('click',()=>closeModal($('#account-modal'))));
$('#node-modal .modal-close').addEventListener('click',()=>closeModal($('#node-modal')));
$$('.modal-backdrop').forEach(backdrop=>backdrop.addEventListener('mousedown',event=>event.target===backdrop&&closeModal(backdrop)));

$('#node-form').addEventListener('submit', async event => {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(event.target));
  values.ssh_port = Number(values.ssh_port);
  if (!values.ssh_password) delete values.ssh_password;
  if (!values.ssh_private_key) delete values.ssh_private_key;
  try {
    const result = await api(state.editingNode?`/api/nodes/${state.editingNode}`:'/api/nodes',{method:state.editingNode?'PUT':'POST',body:JSON.stringify(values)});
    closeModal($('#node-modal')); event.target.reset();
    if(state.editingNode){showToast('NODE UPDATED',result.ssh_pin_reset?'Connection changed; SSH fingerprint will be pinned again.':'Node settings saved.');state.editingNode=null;}
    else{$('#agent-token').textContent = result.agent_token;$('#token-backdrop').classList.add('open');}
    await refresh();
  } catch (error) { showToast('NODE REGISTRATION FAILED',error.message,true); }
});

$('#copy-token').addEventListener('click',async()=>{await navigator.clipboard.writeText($('#agent-token').textContent);showToast('TOKEN COPIED','Use it once in the Agent installer.');});
$('#plugin-iran-node').addEventListener('change',event=>{const node=state.nodes.find(item=>item.id===Number(event.target.value));if(node)$('#plugin-endpoint').value=node.host;});
$('#close-token').addEventListener('click',()=>$('#token-backdrop').classList.remove('open'));
$('#open-command').addEventListener('click',()=>openModal('#command-modal'));
$('#command-input').addEventListener('input',event=>{$$('.command-option').forEach(button=>button.hidden=!button.textContent.toLowerCase().includes(event.target.value.toLowerCase()));});
$('#alert-button').addEventListener('click',()=>switchView('incidents'));
$('#list-view').addEventListener('click',()=>switchView('tunnels'));
$('#map-view').addEventListener('click',()=>switchView('overview'));

document.addEventListener('click', event => {
  const jump = event.target.closest('[data-jump]');
  const takeControl = event.target.closest('#take-control');
  const pluginDeploy = event.target.closest('.plugin-deploy');
  const ssh = event.target.closest('.server-ssh');
  const diagnostics = event.target.closest('.node-diagnostics');
  const logs = event.target.closest('.node-logs');
  const deleteNode = event.target.closest('.node-delete');
  const restartTunnel = event.target.closest('.tunnel-restart');
  const deployRetry = event.target.closest('.deploy-retry');
  const deployRemove = event.target.closest('.deploy-remove');
  const topologyNode = event.target.closest('.node[data-node]');
  const editNode = event.target.closest('.node-edit');
  const rotateToken = event.target.closest('.node-token');
  const resetPin = event.target.closest('.node-pin');
  const serviceRestart = event.target.closest('.service-chip');
  const incidentAck = event.target.closest('.incident-ack');
  const incidentResolve = event.target.closest('.incident-resolve');
  const autohealNode = event.target.closest('.node-autoheal');
  if (jump) { switchView(jump.dataset.jump); const modal=jump.closest('.modal-backdrop'); if(modal)closeModal(modal); }
  if (takeControl) { const node=state.nodes.find(item=>item.id===Number(takeControl.dataset.nodeId))||state.nodes.find(item=>item.status!=='online')||state.nodes[0]; if(node)connectSSH(node.id); else showToast('NO NODE AVAILABLE','Add a server first.',true); }
  if (pluginDeploy) {
    const online = state.nodes.filter(node=>node.status==='online');
    const iranNodes=online.filter(node=>node.role==='edge'), kharejNodes=online.filter(node=>node.role==='exit');
    if (!iranNodes.length || !kharejNodes.length) return showToast('IRAN + KHAREJ REQUIRED','At least one online Iran Edge and one online Global Exit Agent are required.',true);
    $('#plugin-iran-node').innerHTML = iranNodes.map(node=>`<option value="${Number(node.id)}">${esc(node.name)} · ${esc(node.host)}</option>`).join('');
    $('#plugin-kharej-node').innerHTML = kharejNodes.map(node=>`<option value="${Number(node.id)}">${esc(node.name)} · ${esc(node.host)}</option>`).join('');
    const iran = iranNodes[0];
    const kharej = kharejNodes[0];
    $('#plugin-iran-node').value=iran.id; $('#plugin-kharej-node').value=kharej.id; $('#plugin-endpoint').value=iran.host;
    openModal('#plugin-modal');
  }
  if (ssh) connectSSH(ssh.dataset.nodeId);
  if (diagnostics) createJob(Number(diagnostics.dataset.nodeId),'diagnostics',null,{},true).catch(error=>showToast('COMMAND FAILED',error.message,true));
  if (logs) createJob(Number(logs.dataset.nodeId),'logs',null,{},true).catch(error=>showToast('LOG REQUEST FAILED',error.message,true));
  if (deleteNode && confirm(`Delete node “${deleteNode.dataset.nodeName}” and its telemetry from DARK NOC?`)) api(`/api/nodes/${Number(deleteNode.dataset.nodeId)}`,{method:'DELETE'}).then(()=>{showToast('NODE DELETED',`${deleteNode.dataset.nodeName} was removed from the Hub.`);refresh();}).catch(error=>showToast('DELETE FAILED',error.message,true));
  if (restartTunnel) { if(!restartTunnel.dataset.service)return showToast('NO SERVICE DEFINED','Register a systemd service for this tunnel first.',true); if(confirm(`Restart ${restartTunnel.dataset.service}?`))createJob(Number(restartTunnel.dataset.nodeId),'restart_service',restartTunnel.dataset.service,{},true).then(()=>setTimeout(refresh,3500)); }
  if (deployRetry) api(`/api/plugin-deployments/${Number(deployRetry.dataset.deploymentId)}/retry`,{method:'POST'}).then(()=>{showToast('RETRY QUEUED','Only the failed side will be deployed again.');refresh();}).catch(error=>showToast('RETRY FAILED',error.message,true));
  if (deployRemove && confirm('Remove this DARK Backhaul tunnel from both servers?')) api(`/api/plugin-deployments/${Number(deployRemove.dataset.deploymentId)}/remove`,{method:'POST'}).then(()=>{showToast('REMOVAL QUEUED','The tunnel will be removed from both Agents.');refresh();}).catch(error=>showToast('REMOVAL FAILED',error.message,true));
  if (topologyNode) { const node=state.nodes.find(item=>item.name===topologyNode.dataset.node); switchView('servers'); if(node) showToast('NODE LOCATED',`${node.name} · ${node.status}`); }
  if(editNode){const node=state.nodes.find(item=>item.id===Number(editNode.dataset.nodeId));if(node){state.editingNode=node.id;$('#node-title').textContent=`Edit ${node.name}`;const form=$('#node-form');for(const key of ['name','host','ssh_port','region','role','ssh_user']){if(form.elements[key])form.elements[key].value=node[key]??'';}form.elements.ssh_password.value='';form.elements.ssh_private_key.value='';openModal('#node-modal');}}
  if(rotateToken&&confirm('Rotate this Agent token? The Agent will go offline until its config is updated.'))api(`/api/nodes/${Number(rotateToken.dataset.nodeId)}/rotate-token`,{method:'POST'}).then(result=>{$('#agent-token').textContent=result.agent_token;$('#token-backdrop').classList.add('open');refresh();}).catch(error=>showToast('TOKEN ROTATION FAILED',error.message,true));
  if(resetPin&&confirm('Forget the pinned SSH fingerprint? Only do this after verifying the server key changed.'))api(`/api/nodes/${Number(resetPin.dataset.nodeId)}/ssh-fingerprint`,{method:'DELETE'}).then(()=>showToast('SSH PIN RESET','The next SSH connection will pin the presented host key.')).catch(error=>showToast('PIN RESET FAILED',error.message,true));
  if(serviceRestart&&confirm(`Restart ${serviceRestart.dataset.serviceName}?`))createJob(Number(serviceRestart.dataset.serviceNode),'restart_service',serviceRestart.dataset.serviceName,{},true).then(()=>setTimeout(refresh,2500)).catch(error=>showToast('SERVICE RESTART FAILED',error.message,true));
  if(incidentAck)api(`/api/incidents/${Number(incidentAck.dataset.incidentId)}/action`,{method:'POST',body:JSON.stringify({action:'acknowledge'})}).then(refresh).catch(error=>showToast('INCIDENT ACTION FAILED',error.message,true));
  if(incidentResolve&&confirm('Resolve this incident manually?'))api(`/api/incidents/${Number(incidentResolve.dataset.incidentId)}/action`,{method:'POST',body:JSON.stringify({action:'resolve'})}).then(refresh).catch(error=>showToast('INCIDENT ACTION FAILED',error.message,true));
  if(autohealNode){const node=state.nodes.find(item=>item.id===Number(autohealNode.dataset.nodeId));if(node){const enabled=!Boolean(node.autoheal_enabled);if(confirm(`${enabled?'Enable':'Disable'} Auto-Heal on ${node.name}?`))createJob(node.id,'configure_autoheal',null,{enabled,cooldown_seconds:Number(node.autoheal_cooldown||300),max_restarts_per_hour:Number(node.autoheal_max_restarts||3)},true).then(()=>setTimeout(refresh,3000)).catch(error=>showToast('AUTO-HEAL UPDATE FAILED',error.message,true));}}
});

$('#plugin-iran-node').addEventListener('change',event=>{const node=state.nodes.find(item=>item.id===Number(event.target.value));if(node)$('#plugin-endpoint').value=node.host;});
$('#plugin-form').addEventListener('submit',async event=>{
  event.preventDefault();
  const values=Object.fromEntries(new FormData(event.target));
  values.iran_node_id=Number(values.iran_node_id); values.kharej_node_id=Number(values.kharej_node_id); values.tunnel_port=Number(values.tunnel_port);
  values.user_ports=String(values.user_ports).split(/[ ,]+/).filter(Boolean).map(Number);
  if(values.iran_node_id===values.kharej_node_id)return showToast('INVALID NODE PAIR','Iran and Kharej must be different servers.',true);
  try{
    const deployment=await api('/api/plugins/dark-backhaul/deploy',{method:'POST',body:JSON.stringify(values)});
    closeModal($('#plugin-modal')); showToast('DUAL DEPLOYMENT QUEUED',`Deployment #${deployment.deployment_id} is running on both Agents.`); event.target.reset(); await refresh();
  }catch(error){showToast('PLUGIN DEPLOYMENT FAILED',error.message,true);}
});

$$('.terminal-input').forEach(form=>form.addEventListener('submit',event=>{
  event.preventDefault(); const input=$('input',form); const socket=state.sockets.get(form.dataset.terminal);
  if (!socket || socket.readyState!==WebSocket.OPEN) return showToast('SSH NOT CONNECTED','Open SSH from a server card first.',true);
  socket.send(JSON.stringify({type:'input',data:`${input.value}\n`})); input.value='';
}));

$('#clear-terminal').addEventListener('click',()=>$$('.terminal-screen').forEach(screen=>screen.textContent=''));
$('#disconnect').addEventListener('click',()=>{[...state.sockets.keys()].forEach(closeSocket);showToast('SSH DISCONNECTED','All interactive sessions were closed.');});
$('#run-all-tests').addEventListener('click',async()=>{const online=state.nodes.filter(node=>node.status==='online');if(!online.length)return showToast('NO ONLINE AGENTS','Tunnel tests were not queued.',true);await Promise.all(online.map(node=>createJob(node.id,'tunnel_test')));showToast('TUNNEL TESTS QUEUED',`${online.length} online Agent${online.length===1?'':'s'} will test every configured tunnel.`);});
$('#filter-nodes').addEventListener('click',event=>{state.nodeFilter=state.nodeFilter==='all'?'attention':'all';event.target.textContent=`FILTER: ${state.nodeFilter==='all'?'ALL':'ATTENTION'}`;renderNodes();});
$('#export-incidents').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(state.incidents,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`dark-noc-incidents-${Date.now()}.json`;a.click();URL.revokeObjectURL(a.href);});
$('#session-log').addEventListener('click',async()=>{try{const jobs=await api('/api/jobs?limit=100');$('#output-title').textContent='Remote job history';$('#job-output').textContent=jobs.map(job=>`#${job.id} [${job.status}] ${job.node_name} · ${job.kind}\n${job.output||''}`).join('\n\n');openModal('#output-modal');}catch(error){showToast('HISTORY FAILED',error.message,true);}});
$('#copy-output').addEventListener('click',async()=>{await navigator.clipboard.writeText($('#job-output').textContent);showToast('OUTPUT COPIED','Command output copied to clipboard.');});
$$('.terminal-card').forEach(card=>card.addEventListener('click',()=>{$$('.terminal-card').forEach(item=>item.classList.remove('active-terminal'));card.classList.add('active-terminal');}));
$$('[data-command]').forEach(button=>button.addEventListener('click',()=>{const active=$('.terminal-card.active-terminal .terminal-screen');const slots=[active?.id,'terminal-iran','terminal-germany'].filter(Boolean);const socket=slots.map(slot=>state.sockets.get(slot)).find(item=>item?.readyState===WebSocket.OPEN);if(!socket)return showToast('SSH NOT CONNECTED','Open SSH from a server card first.',true);socket.send(JSON.stringify({type:'input',data:`${button.dataset.command}\n`}));}));
$('.operator').addEventListener('click',async()=>{try{const me=await api('/api/auth/me');$('#account-form [name="username"]').value=me.username;$('#account-form').reset();$('#account-form [name="username"]').value=me.username;openModal('#account-modal');}catch(error){showToast('ACCOUNT ERROR',error.message,true);}});
$('#account-form').addEventListener('submit',async event=>{event.preventDefault();const values=Object.fromEntries(new FormData(event.target));if(values.new_password!==values.confirm_password)return showToast('PASSWORD MISMATCH','New password confirmation does not match.',true);delete values.confirm_password;if(!values.new_password)delete values.new_password;try{const result=await api('/api/auth/account',{method:'PUT',body:JSON.stringify(values)});closeModal($('#account-modal'));event.target.reset();showToast('ACCOUNT UPDATED',result.reauthenticate?'Sign in again with the new credentials.':'Username saved.');if(result.reauthenticate){$('#login-gate').classList.remove('hidden');if(liveSocket)liveSocket.close();}else $('.operator strong').textContent=result.username;}catch(error){showToast('ACCOUNT UPDATE FAILED',error.message,true);}});
$('#logout-button').addEventListener('click',async()=>{await api('/api/auth/logout',{method:'POST'});$('#login-gate').classList.remove('hidden');if(liveSocket)liveSocket.close();closeModal($('#account-modal'));});

document.addEventListener('keydown',event=>{
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();openModal('#command-modal');}
  if(event.key==='Escape'){$$('.modal-backdrop.open').forEach(closeModal);$('#token-backdrop').classList.remove('open');}
});

function updateClock(){ $('#clock').textContent=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tehran',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date()); }
updateClock(); setInterval(updateClock,1000); setInterval(refresh,15000); boot();
